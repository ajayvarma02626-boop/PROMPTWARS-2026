/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from "react";
import { JournalEntry, ExamType } from "./types";
import JournalLogger from "./components/JournalLogger";
import DashboardStats from "./components/DashboardStats";
import CompanionBot from "./components/CompanionBot";
import TestHarness from "./components/TestHarness";
import { 
  Heart, LayoutDashboard, MessageCircle, BookMarked, ShieldCheck, 
  Settings, HelpCircle, Check, Languages
} from "lucide-react";

// Multi-language system dictionary for inclusivity
type LangType = "en" | "hi" | "hinglish";

const translations: Record<LangType, Record<string, string>> = {
  en: {
    appTitle: "Aspirant Wellness Tracker",
    tagline: "Empathetic mental companion mitigating exam stress & burnout",
    tabJournal: "Daily Journal & Report",
    tabDashboard: "Wellness Analytics",
    tabCompanion: "Sahaya AI Chatbot",
    tabTests: "Integrity Test Suite",
    examSelector: "Selected Active Exam Prep:",
    warningTitle: "Demo Mode Active",
    warningBody: "Running with simulated analysis. Connect a GEMINI_API_KEY secret on AI Studio for real-time live LLM capabilities.",
    footerDisclaimer: "Sahaya provides non-clinical educational psychology coping exercises. In case of acute emotional distress, consult a certified counsellor.",
    examChangeHint: "Modifying exam modifies the AI counselor's contextual focus and greeting metrics."
  },
  hi: {
    appTitle: "आकांक्षी मानसिक स्वास्थ्य ट्रैकर",
    tagline: "परीक्षा तनाव और मानसिक थकान को कम करने वाला संवेदनशील डिजिटल साथी",
    tabJournal: "दैनिक जर्नल और रिपोर्ट",
    tabDashboard: "स्वास्थ्य विश्लेषिकी",
    tabCompanion: "सहायक एआई चैटबॉट",
    tabTests: "सत्यता परीक्षण सूट",
    examSelector: "सक्रिय परीक्षा तैयारी:",
    warningTitle: "डेमो मोड सक्रिय",
    warningBody: "सिम्युलेटेड विश्लेषण के साथ चल रहा है। रीयल-टाइम लाइव एलएलएम के लिए एआई स्टूडियो पर जेमिनी एपीआई की कनेक्ट करें।",
    footerDisclaimer: "सहायक केवल सामान्य मानसिक स्वास्थ्य सहायक रणनीतियाँ प्रदान करता है। तीव्र संकट की स्थिति में, कृप्या किसी विशेषज्ञ से परामर्श लें।",
    examChangeHint: "परीक्षा बदलने से एआई साथी का ध्यान और उसकी प्रतिक्रियाएं उस परीक्षा के अनुसार बदल जाती हैं।"
  },
  hinglish: {
    appTitle: "Aspirant Wellness Tracker",
    tagline: "Exam stress aur burnout kam karne wala dynamic AI companion",
    tabJournal: "Daily Journal & Report",
    tabDashboard: "Stress Graphs & Diagnostics",
    tabCompanion: "AI Sahaya Counselor",
    tabTests: "Backend Test Suite",
    examSelector: "Aapki active Exam prep:",
    warningTitle: "Demo/Offline Mode On",
    warningBody: "Simulated analytics chal rahe hain. Live GenAI ke liye AI Studio settings me GEMINI_API_KEY add karein.",
    footerDisclaimer: "Sahaya ek self-regulation wellness tool hai. Clinical mental health support ke liye, certified doctor se contact karein.",
    examChangeHint: "Exam change karne se AI companion ka tone aur greeting response us exam ke mutabik set ho jayega."
  }
};

export default function App() {
  const [entries, setEntries] = useState<JournalEntry[]>([]);
  const [activeTab, setActiveTab] = useState<"journal" | "dashboard" | "companion" | "tests">("journal");
  const [selectedExam, setSelectedExam] = useState<ExamType>("GATE");
  const [currentLang, setCurrentLang] = useState<LangType>("en");

  // Load static mock datasets for validation if first time opening empty dashboard
  useEffect(() => {
    const saved = localStorage.getItem("wellness_aspirant_entries");
    if (saved) {
      try {
        setEntries(JSON.parse(saved));
      } catch (e) {
        console.error("Local storage corruption:", e);
      }
    } else {
      // Setup detailed mock journaling dataset reflecting typical student logs
      const defaultMockEntries: JournalEntry[] = [
        {
          id: "mock-1",
          date: "2026-06-08",
          exam: "GATE",
          text: "[AES-256 ENCRYPTED PERSISTENCE] (View Plain Text available below)",
          encryptedText: "cb46a9e10bfca7b9:7fe39cb91a2ebffca2ea10b64d3fe90fbcf394f",
          moodScore: 4,
          status: "analyzed",
          analysis: {
            moodScore: 4,
            stressLevel: 8,
            burnoutRisk: 75,
            dominantEmotions: ["Overwhelmed", "Anxious"],
            detectedTriggers: ["Virtual Calculator Speeds", "Concept Derivation Fatigue"],
            cognitiveDistortions: ["All-or-Nothing Thinking", "Catastrophizing"],
            emotionalPatterns: "Recurrent anxiety spikes related to engineering math numerical timers. Focus decays during long tests.",
            motivationScore: 5,
            copingStrategies: [
              {
                id: "strat-mock-1",
                title: "Vagus Nerve Derivation Reset",
                type: "mindfulness",
                difficulty: "Easy",
                durationMinutes: 5,
                steps: [
                  "Push your chair 2 feet back from your laptop screener.",
                  "Shut your eyes and count slow breaths in for 4 seconds, holding for 4.",
                  "Exhale slowly to release virtual engineering calculator timing panic."
                ]
              }
            ],
            personalizedNudge: "Thermodynamics and conceptual derivations are highly challenging benchmarks. Your score in a single rehearsal mock test does not reflect your engineering capacity. Stay balanced."
          }
        },
        {
          id: "mock-2",
          date: "2026-06-10",
          exam: "UPSC",
          text: "[AES-256 ENCRYPTED PERSISTENCE] (View Plain Text available below)",
          encryptedText: "ef82ba542cdbe90fca7:112a9e223bf947ea9fce9a6b09bf94f",
          moodScore: 5,
          status: "analyzed",
          analysis: {
            moodScore: 5,
            stressLevel: 7,
            burnoutRisk: 62,
            dominantEmotions: ["Exhausted", "Determined"],
            detectedTriggers: ["History Syllabus Vastness", "Answer Writing Isolation"],
            cognitiveDistortions: ["Overgeneralization"],
            emotionalPatterns: "Strong work ethic but suffering from long static sitting strain. Fatigue patterns visible in current affairs notes.",
            motivationScore: 6,
            copingStrategies: [
              {
                id: "strat-mock-2",
                title: "Isolation Stretch & Stand Refresh",
                type: "action",
                difficulty: "Easy",
                durationMinutes: 8,
                steps: [
                  "Stand up and do a overhead stretch for 30 seconds.",
                  "Step away from your general history notebooks.",
                  "Refrain from looking at current news indexes for 5 minutes."
                ]
              }
            ],
            personalizedNudge: "Civil Services prep is a massive marathon, not an overnight sprint. Taking rest is a core part of strategy blocks."
          }
        },
        {
          id: "mock-3",
          date: "2026-06-11",
          exam: "GATE",
          text: "[AES-256 ENCRYPTED PERSISTENCE] (View Plain Text available below)",
          encryptedText: "fa20de11bfca79a1:efcbcf3901bca2ed00a2ee4bc1bca2ed00bf94fdcf",
          moodScore: 7,
          status: "analyzed",
          analysis: {
            moodScore: 7,
            stressLevel: 4,
            burnoutRisk: 38,
            dominantEmotions: ["Relieved", "Motivated"],
            detectedTriggers: ["Numerical Aptitude Practice"],
            cognitiveDistortions: [],
            emotionalPatterns: "Confidence restored after successful review session on math linear equations and probability blocks.",
            motivationScore: 8,
            copingStrategies: [
              {
                id: "strat-mock-3",
                title: "Confidence Consolidation Review",
                type: "motivational",
                difficulty: "Easy",
                durationMinutes: 5,
                steps: [
                  "Log this successful practice outcome cleanly in your scheduler.",
                  "Reflect on how practice yields conceptual ease.",
                  "Take a light study milestone walk to lock in focus retention."
                ]
              }
            ],
            personalizedNudge: "Excellent effort today. You have proven yourself to adapt when revising parameters sequentially."
          }
        }
      ];
      setEntries(defaultMockEntries);
      localStorage.setItem("wellness_aspirant_entries", JSON.stringify(defaultMockEntries));
    }
  }, []);

  const handleAddEntry = (newEntry: JournalEntry) => {
    const updated = [...entries, newEntry];
    setEntries(updated);
    localStorage.setItem("wellness_aspirant_entries", JSON.stringify(updated));
  };

  const handleUpdateEntry = (id: string, updatedFields: Partial<JournalEntry>) => {
    const updated = entries.map((e) => {
      if (e.id === id) {
        return { ...e, ...updatedFields };
      }
      return e;
    });
    setEntries(updated);
    localStorage.setItem("wellness_aspirant_entries", JSON.stringify(updated));
  };

  const t = translations[currentLang];

  return (
    <div className="min-h-screen bg-[#F8FAFC] flex flex-col justify-between selection:bg-indigo-150">
      
      {/* Top Professional Header Bar */}
      <header className="bg-white/80 backdrop-blur-md border-b border-slate-200/80 sticky top-0 z-50 shadow-sm shadow-slate-100/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-indigo-600 flex items-center justify-center shadow-lg shadow-indigo-150">
              <Heart className="w-5 h-5 text-white fill-white/10 animate-pulse" />
            </div>
            <div>
              <h1 className="text-sm font-extrabold text-slate-900 leading-tight tracking-tight">
                {t.appTitle}
              </h1>
              <p className="text-[10px] text-slate-500 font-semibold italic">
                {t.tagline}
              </p>
            </div>
          </div>

          {/* Quick controls: Exam Context & Language selector */}
          <div className="flex items-center gap-4">
            
            {/* Language Selector Dropdown */}
            <div className="flex items-center gap-1.5 border border-slate-200 px-2.5 py-1.5 rounded-xl bg-slate-50/50 hover:bg-slate-55 transition-colors">
              <Languages className="w-3.5 h-3.5 text-slate-500" />
              <select
                value={currentLang}
                onChange={(e) => setCurrentLang(e.target.value as LangType)}
                aria-label="Select App Language"
                className="text-xs bg-transparent outline-none border-none text-slate-700 font-bold cursor-pointer"
              >
                <option value="en">English</option>
                <option value="hi">हिंदी (Hindi)</option>
                <option value="hinglish">Hinglish</option>
              </select>
            </div>

            {/* Global Active Exam context selector */}
            <div className="hidden md:flex items-center gap-2">
              <span className="text-[10.5px] font-bold text-slate-400 uppercase tracking-widest font-mono shrink-0">
                {t.examSelector}
              </span>
              <select
                value={selectedExam}
                onChange={(e) => setSelectedExam(e.target.value as ExamType)}
                aria-label="Select Target Exam Prep Focus"
                className="text-xs bg-white border border-slate-200 hover:border-slate-300 px-3 py-1.5 rounded-xl font-bold text-indigo-700 outline-none shadow-sm cursor-pointer"
                title={t.examChangeHint}
              >
                <option value="CAT">1) CAT prep focus</option>
                <option value="GATE">2) GATE prep focus</option>
                <option value="UPSC">3) UPSC prep focus</option>
                <option value="JEE">4) JEE prep focus</option>
              </select>
            </div>
          </div>
        </div>
      </header>

      {/* Main Container Area */}
      <main className="flex-grow max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
        
        {/* Mobile Exam Context selector info banner */}
        <div className="md:hidden flex items-center justify-between p-4 bg-white rounded-2xl border border-slate-200 shadow-sm">
          <span className="text-xs font-bold text-slate-500">{t.examSelector}</span>
          <select
            value={selectedExam}
            onChange={(e) => setSelectedExam(e.target.value as ExamType)}
            aria-label="Select Target Exam Prep Focus Mobile"
            className="text-xs bg-white border border-slate-200 px-2 py-1 rounded-xl text-indigo-600 font-semibold"
          >
            <option value="CAT">CAT</option>
            <option value="GATE">GATE</option>
            <option value="UPSC">UPSC</option>
            <option value="JEE">JEE</option>
          </select>
        </div>

        {/* Tab Selection Row (touch target >= 44px) */}
        <div className="flex bg-white p-1.5 rounded-2xl border border-slate-200 shadow-sm overflow-x-auto no-scrollbar gap-1">
          <button
            onClick={() => setActiveTab("journal")}
            className={`flex-1 py-3 px-4 text-xs font-semibold rounded-xl transition-all flex items-center justify-center gap-2 shrink-0 cursor-pointer ${
              activeTab === "journal"
                ? "bg-indigo-600 text-white shadow-md shadow-indigo-100 font-extrabold"
                : "text-slate-500 hover:text-slate-800 hover:bg-slate-50"
            }`}
            style={{ minHeight: "44px" }}
          >
            <BookMarked className="w-4 h-4" />
            {t.tabJournal}
          </button>
          
          <button
            onClick={() => setActiveTab("dashboard")}
            className={`flex-1 py-3 px-4 text-xs font-semibold rounded-xl transition-all flex items-center justify-center gap-2 shrink-0 cursor-pointer ${
              activeTab === "dashboard"
                ? "bg-indigo-600 text-white shadow-md shadow-indigo-100 font-extrabold"
                : "text-slate-500 hover:text-slate-800 hover:bg-slate-50"
            }`}
            style={{ minHeight: "44px" }}
          >
            <LayoutDashboard className="w-4 h-4" />
            {t.tabDashboard}
          </button>

          <button
            onClick={() => setActiveTab("companion")}
            className={`flex-1 py-3 px-4 text-xs font-semibold rounded-xl transition-all flex items-center justify-center gap-2 shrink-0 cursor-pointer ${
              activeTab === "companion"
                ? "bg-indigo-600 text-white shadow-md shadow-indigo-100 font-extrabold"
                : "text-slate-500 hover:text-slate-800 hover:bg-slate-50"
            }`}
            style={{ minHeight: "44px" }}
          >
            <MessageCircle className="w-4 h-4" />
            {t.tabCompanion}
          </button>

          <button
            onClick={() => setActiveTab("tests")}
            className={`flex-1 py-3 px-4 text-xs font-semibold rounded-xl transition-all flex items-center justify-center gap-2 shrink-0 cursor-pointer ${
              activeTab === "tests"
                ? "bg-indigo-600 text-white shadow-md shadow-indigo-100 font-extrabold"
                : "text-slate-500 hover:text-slate-800 hover:bg-slate-50"
            }`}
            style={{ minHeight: "44px" }}
          >
            <ShieldCheck className="w-4 h-4" />
            {t.tabTests}
          </button>
        </div>

        {/* Dynamic Inner views based on Selected Active Tab */}
        <div className="transition-all duration-200">
          {activeTab === "journal" && (
            <JournalLogger 
              entries={entries} 
              onAddEntry={handleAddEntry} 
              onUpdateEntry={handleUpdateEntry} 
              lang={currentLang}
            />
          )}

          {activeTab === "dashboard" && (
            <DashboardStats entries={entries} />
          )}

          {activeTab === "companion" && (
            <CompanionBot exam={selectedExam} />
          )}

          {activeTab === "tests" && (
            <TestHarness />
          )}
        </div>

      </main>

      {/* Structured Footer */}
      <footer className="bg-white border-t border-neutral-200 py-6 mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-3">
          <div className="flex justify-center items-center gap-4 text-[10.5px] font-mono text-neutral-400">
            <span className="flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5 text-indigo-500" /> Secure AES-256 Storage
            </span>
            <span>•</span>
            <span className="flex items-center gap-1">
              👑 Empathetic Sahaya Digital Assistant
            </span>
            <span>•</span>
            <span>Local Time: 2026-06-13</span>
          </div>

          <p className="text-[10px] text-neutral-400 max-w-2xl mx-auto leading-relaxed">
            {t.footerDisclaimer}
          </p>
        </div>
      </footer>

    </div>
  );
}
