/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type ExamType = 'CAT' | 'GATE' | 'UPSC' | 'JEE';

export interface CopingStrategy {
  id: string;
  title: string;
  type: 'mindfulness' | 'cognitive' | 'action' | 'motivational';
  difficulty: 'Easy' | 'Medium' | 'Challenging';
  durationMinutes: number;
  steps: string[];
}

export interface JournalAnalysis {
  moodScore: number; // 1 to 10
  stressLevel: number; // 1 to 10
  burnoutRisk: number; // 0 to 100
  dominantEmotions: string[];
  detectedTriggers: string[];
  cognitiveDistortions: string[]; // e.g., "All-or-Nothing thinking", "Catastrophizing"
  emotionalPatterns: string;
  motivationScore: number; // 1 to 10
  copingStrategies: CopingStrategy[];
  personalizedNudge: string;
}

export interface JournalEntry {
  id: string;
  date: string; // ISO String or YYYY-MM-DD
  exam: ExamType;
  text: string;
  encryptedText?: string; // For security persistence
  moodScore: number; // 1 to 10
  analysis: JournalAnalysis | null;
  status: 'pending' | 'analyzed' | 'error';
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  text: string;
  timestamp: string;
}

export interface WellnessDashboardStats {
  moodTrend: { date: string; moodScore: number; stressLevel: number }[];
  triggerFrequencies: { name: string; count: number }[];
  burnoutProgression: { date: string; risk: number }[];
  copingCompletionRate: number;
  examFocusDistribution: { exam: ExamType; count: number }[];
}

export interface UnitTestResult {
  testName: string;
  category: 'mood' | 'triggers' | 'strategies' | 'security';
  status: 'passed' | 'failed' | 'running';
  message: string;
}
