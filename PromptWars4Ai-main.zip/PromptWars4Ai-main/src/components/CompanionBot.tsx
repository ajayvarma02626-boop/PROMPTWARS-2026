/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useRef, useEffect } from "react";
import { ChatMessage, ExamType } from "../types";
import { Send, Sparkles, MessageCircle, RefreshCw, User, Loader2, Compass } from "lucide-react";

interface CompanionBotProps {
  exam: ExamType;
}

export default function CompanionBot({ exam }: CompanionBotProps) {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputText, setInputText] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  
  const bottomRef = useRef<HTMLDivElement>(null);

  // Initial greeting based on exam type
  useEffect(() => {
    const defaultGreetings: Record<ExamType, string> = {
      CAT: "Namaste! I am Sahaya, your CAT counseling companion. Percentage target jitters, speed drills, and Logical Reasoning and Data Interpretation can feel completely exhausting. I am here as an empathetic, always-available digital companion. Tell me, how are your prep metrics feeling today?",
      GATE: "Hello! I am Sahaya, your GATE companion. Engineering derivations, virtual calculators, and numerical aptitude criteria have massive structural pressures. I'm right here with you. What concept revision or performance doubt is bugging you?",
      UPSC: "Greetings! I am Sahaya, your UPSC companion. Studying infinite General Studies syllabi, writing continuous test briefs, and current events can cause massive burnout. I'm a safe, completely non-clinical harbor for your thoughts. How are you coping with today's study goal?",
      JEE: "Hey! I am Sahaya, your JEE companion. Rigorous Physics calculations, complex organic chemistry equations, and peer scoring pressure can trigger intense imposter syndrome. I am on your team, completely. Describe what is on your mind right now."
    };

    setMessages([
      {
        id: "greet-" + Date.now(),
        role: "assistant",
        text: defaultGreetings[exam] || "Hello! I am Sahaya, your wellness companion. Tell me what is on your mind.",
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      }
    ]);
  }, [exam]);

  // Scroll to bottom on updates
  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isLoading]);

  const handleSendMessage = async (textToSend: string) => {
    if (!textToSend.trim()) return;

    const userMsg: ChatMessage = {
      id: "u-" + Date.now(),
      role: "user",
      text: textToSend,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages(prev => [...prev, userMsg]);
    setInputText("");
    setIsLoading(true);

    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          messages: [...messages, userMsg].map(m => ({ role: m.role, text: m.text })),
          exam: exam
        })
      });

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}`);
      }

      const data = await response.json();
      const assistantMsg: ChatMessage = {
        id: "a-" + Date.now(),
        role: "assistant",
        text: data.text,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };

      setMessages(prev => [...prev, assistantMsg]);
    } catch (err: any) {
      console.error(err);
      const errorMsg: ChatMessage = {
        id: "err-" + Date.now(),
        role: "assistant",
        text: "I am having temporary difficulties syncing our connection, but remember: your worth is far greater than your test results. Take a slow, restorative inhale. I am still here with you.",
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      setMessages(prev => [...prev, errorMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  const quickTriggers: Record<ExamType, string[]> = {
    CAT: [
      "Stressing about Mock Percentile score",
      "VARC sections timing is triggering panic",
      "Comparing myself to corporate workers"
    ],
    GATE: [
      "I forgot basic formulas in derivations",
      "Numerical Answer Type precision is exhausting",
      "Want a 5-minute math stress-relief break"
    ],
    UPSC: [
      "The sheer General Studies syllabus feels unapproachable",
      "I feel like I will fail my next essay revision",
      "I am facing extreme isolation routine fatigue"
    ],
    JEE: [
      "My coaching rank dropped this week",
      "Organic Chemistry mechanisms feel confusing",
      "I feel like my parents expect perfect percentiles"
    ]
  };

  return (
    <div className="bg-white rounded-3xl shadow-sm border border-slate-100 overflow-hidden flex flex-col h-[520px]" id="sahaya-companion-bot">
      
      {/* Bot Header */}
      <div className="p-5 bg-gradient-to-r from-indigo-600 to-violet-700 text-white flex items-center justify-between shadow-md">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-white/20 border border-white/20 flex items-center justify-center text-lg animate-pulse">
            🕊️
          </div>
          <div>
            <div className="font-extrabold text-xs flex items-center gap-1.5 text-white">
              Sahaya AI Companion
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping"></span>
            </div>
            <p className="text-[10px] text-indigo-100 font-mono tracking-tight font-semibold">
              Empathetic counseling voice for {exam} candidates
            </p>
          </div>
        </div>

        <button 
          onClick={() => {
            if (confirm("Reset current conversation thread?")) {
              setMessages([
                {
                  id: "greet-" + Date.now(),
                  role: "assistant",
                  text: `Thread reset completed. What high-stakes test hurdles or stress levels can we work on?`,
                  timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
                }
              ]);
            }
          }}
          className="p-2 outline-none hover:bg-white/10 text-white/80 hover:text-white rounded-xl transition-all cursor-pointer"
          title="Reset conversation"
        >
          <RefreshCw className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Message List area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-slate-50/40">
        {messages.map((m) => {
          const isUser = m.role === "user";
          return (
            <div
              key={m.id}
              className={`flex items-start gap-2.5 max-w-[85%] ${
                isUser ? "ml-auto flex-row-reverse" : "mr-auto"
              }`}
            >
              <div
                className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 text-xs font-bold ${
                  isUser 
                    ? "bg-indigo-600 text-white" 
                    : "bg-slate-800 text-white border border-slate-700 shadow"
                }`}
              >
                {isUser ? <User className="w-4 h-4" /> : "🕊️"}
              </div>

              <div className="space-y-1">
                <div
                  className={`p-3.5 rounded-2xl text-xs leading-relaxed ${
                    isUser
                      ? "bg-indigo-600 text-white rounded-tr-none font-semibold shadow-sm"
                      : "bg-white text-slate-800 rounded-tl-none border border-slate-100 shadow-sm font-sans font-medium"
                  }`}
                >
                  {m.text}
                </div>
                <div
                  className={`text-[9px] text-slate-400 font-mono font-medium px-1 ${
                    isUser ? "text-right" : "text-left"
                  }`}
                >
                  {m.timestamp}
                </div>
              </div>
            </div>
          );
        })}

        {isLoading && (
          <div className="flex items-start gap-2.5 max-w-[80%] mr-auto animate-pulse">
            <div className="w-8 h-8 rounded-full bg-slate-800 text-white flex items-center justify-center text-xs">
              🕊️
            </div>
            <div className="bg-white p-3 rounded-2xl rounded-tl-none border border-slate-50 flex items-center gap-2 text-xs text-slate-450 font-mono shadow-sm">
              <Loader2 className="w-3.5 h-3.5 animate-spin text-slate-500" />
              Sahaya is formulating a gentle support response...
            </div>
          </div>
        )}

        <div ref={bottomRef} />
      </div>

      {/* Suggested quick distress buttons */}
      <div className="px-4 py-2.5 border-t border-slate-100 bg-white flex items-center gap-1.5 overflow-x-auto select-none no-scrollbar shrink-0">
        <Compass className="w-3.5 h-3.5 text-indigo-500 shrink-0" />
        <div className="flex gap-1.5">
          {quickTriggers[exam]?.map((suggestion, index) => (
            <button
              key={index}
              disabled={isLoading}
              onClick={() => handleSendMessage(suggestion)}
              className="text-[10px] shrink-0 font-bold bg-slate-50 hover:bg-indigo-50 border border-slate-150 hover:border-indigo-200 text-slate-600 hover:text-indigo-700 px-3 py-2 rounded-xl transition-all cursor-pointer disabled:opacity-50"
            >
              {suggestion}
            </button>
          ))}
        </div>
      </div>

      {/* Bottom Message Input Form */}
      <form
        onSubmit={(e) => {
          e.preventDefault();
          handleSendMessage(inputText);
        }}
        className="p-3.5 border-t border-slate-100 bg-white flex items-center gap-2 shrink-0"
      >
        <input
          type="text"
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          placeholder={`Talk about your ${exam} stress or mock score pressure...`}
          disabled={isLoading}
          aria-label="Sahaya Counselor chat message field"
          className="flex-1 text-xs p-3.5 bg-slate-50 border border-slate-200 focus:border-indigo-500 focus:outline-none rounded-2xl text-slate-800 transition-colors disabled:bg-slate-100 disabled:text-slate-400"
        />
        <button
          type="submit"
          disabled={isLoading || !inputText.trim()}
          aria-label="Send message"
          className="p-3.5 bg-indigo-600 hover:bg-indigo-700 text-white disabled:bg-slate-100 disabled:text-slate-400 rounded-2xl transition-all cursor-pointer shadow-md shadow-indigo-100/20"
        >
          <Send className="w-3.5 h-3.5" />
        </button>
      </form>
    </div>
  );
}
