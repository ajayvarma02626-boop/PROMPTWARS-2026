/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useMemo } from "react";
import { JournalEntry } from "../types";
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, BarChart, Bar, Cell, AreaChart, Area } from "recharts";
import { TrendingUp, Activity, AlertTriangle, HelpCircle, LayoutGrid, Sparkles } from "lucide-react";

interface DashboardStatsProps {
  entries: JournalEntry[];
}

export default function DashboardStats({ entries }: DashboardStatsProps) {
  const [screenReaderMode, setScreenReaderMode] = useState(false);

  const analyzedEntries = useMemo(() => {
    return entries
      .filter((e) => e.status === "analyzed" && e.analysis)
      .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
  }, [entries]);

  // 1. Prepare Mood & Stress Trend Data
  const trendData = useMemo(() => {
    return analyzedEntries.map((e) => ({
      date: new Date(e.date).toLocaleDateString(undefined, { month: "short", day: "numeric" }),
      mood: e.analysis?.moodScore || 0,
      stress: e.analysis?.stressLevel || 0,
      burnout: e.analysis?.burnoutRisk || 0,
    }));
  }, [analyzedEntries]);

  // 2. Prepare Trigger Frequencies
  const triggerData = useMemo(() => {
    const triggerMap: Record<string, number> = {};
    analyzedEntries.forEach((e) => {
      e.analysis?.detectedTriggers?.forEach((t) => {
        triggerMap[t] = (triggerMap[t] || 0) + 1;
      });
    });
    return Object.entries(triggerMap)
      .map(([name, count]) => ({ name, count }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 5);
  }, [analyzedEntries]);

  // 3. Cognitive distortions frequency mapping
  const distortionData = useMemo(() => {
    const distortionMap: Record<string, number> = {};
    analyzedEntries.forEach((e) => {
      e.analysis?.cognitiveDistortions?.forEach((d) => {
        distortionMap[d] = (distortionMap[d] || 0) + 1;
      });
    });
    return Object.entries(distortionMap).map(([name, value]) => ({
      name,
      value,
    }));
  }, [analyzedEntries]);

  // Calculations for KPI Cards
  const totalLogs = analyzedEntries.length;

  const recentEntry = useMemo(() => {
    return totalLogs > 0 ? analyzedEntries[totalLogs - 1] : undefined;
  }, [analyzedEntries, totalLogs]);

  const avgMood = useMemo(() => {
    if (totalLogs === 0) return "0.0";
    return (analyzedEntries.reduce((sum, e) => sum + (e.analysis?.moodScore || 0), 0) / totalLogs).toFixed(1);
  }, [analyzedEntries, totalLogs]);

  const avgStress = useMemo(() => {
    if (totalLogs === 0) return "0.0";
    return (analyzedEntries.reduce((sum, e) => sum + (e.analysis?.stressLevel || 0), 0) / totalLogs).toFixed(1);
  }, [analyzedEntries, totalLogs]);

  const currentBurnoutRisk = useMemo(() => {
    return recentEntry?.analysis?.burnoutRisk || 0;
  }, [recentEntry]);

  const suggestedStrategy = useMemo(() => {
    return recentEntry?.analysis?.copingStrategies?.[0] || {
      title: "Box Breathing (4-4-4-4)",
      type: "Mindfulness Reset",
      difficulty: "Easy",
      durationMinutes: 5,
      steps: [
        "Position back upright away from display interface",
        "Inhale slowly for 4 seconds through nostrils",
        "Hold deep breath block for 4 seconds",
        "Release breath easily through mouth"
      ]
    };
  }, [recentEntry]);

  if (analyzedEntries.length === 0) {
    return (
      <div className="bg-white rounded-3xl border border-slate-100 p-12 text-center shadow-sm">
        <div className="mx-auto w-12 h-12 rounded-2xl bg-indigo-50 border border-indigo-100 flex items-center justify-center text-indigo-500 mb-3">
          <Activity className="w-6 h-6 animate-pulse" />
        </div>
        <h3 className="font-extrabold text-slate-800 text-sm">Waiting for Analysis Logs</h3>
        <p className="text-xs text-slate-500 mt-2.5 max-w-sm mx-auto leading-relaxed">
          Write and submit your first daily journal. Our Empathetic GenAI will build stress graphs and trigger indexes instantly.
        </p>
      </div>
    );
  }

  // Set color indicators
  const getBurnoutColor = (risk: number) => {
    if (risk > 70) return "text-red-600 bg-red-50 border-red-200";
    if (risk > 40) return "text-amber-600 bg-amber-50 border-amber-200";
    return "text-emerald-600 bg-emerald-50 border-emerald-200";
  };

  const COLORS = ["#6366f1", "#06b6d4", "#10b981", "#f59e0b", "#ec4899"];

  const stressVal = parseFloat(avgStress) || 5;
  const strokeDashoffset = 251.2 - (251.2 * stressVal) / 10;

  return (
    <div id="stats-dashboard" className="space-y-6">
      
      {/* Top Accessibility Settings Row */}
      <div className="flex flex-wrap items-center justify-between gap-4 bg-white/70 backdrop-blur-md border border-slate-100 p-4 rounded-2xl shadow-sm">
        <div className="flex items-center gap-2">
          <span className="w-2.5 h-2.5 rounded-full bg-indigo-600 animate-ping"></span>
          <span className="text-xs font-bold text-slate-600 uppercase tracking-wider font-mono">Live Session Data Synthesizer Active</span>
        </div>
        <button
          onClick={() => setScreenReaderMode(!screenReaderMode)}
          aria-pressed={screenReaderMode}
          className={`flex items-center gap-2 px-3 tracking-wide py-2 border rounded-xl text-[11px] font-extrabold transition-all cursor-pointer ${
            screenReaderMode
              ? "bg-slate-900 border-slate-900 text-white shadow-md"
              : "bg-white border-slate-250 text-slate-700 hover:bg-slate-50 focus:ring-2 focus:ring-indigo-100"
          }`}
        >
          {screenReaderMode ? "👁️ Show Graphical Charts" : "♿ Enable High-Accessible Text Matrix Mode"}
        </button>
      </div>

      {/* Top Bento Metrics Quick Row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Metric 1 */}
        <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-sm flex items-center justify-between">
          <div>
            <span className="text-xs text-slate-400 font-semibold uppercase tracking-wider block">Total Logs</span>
            <div className="text-2xl font-bold text-slate-800 mt-1">{totalLogs}</div>
            <span className="text-[10px] text-slate-400 mt-0.5 block font-mono">Active diary records</span>
          </div>
          <div className="w-10 h-10 bg-indigo-50 border border-indigo-100 rounded-xl flex items-center justify-center text-indigo-600 shrink-0">
            <TrendingUp className="w-5 h-5" />
          </div>
        </div>

        {/* Metric 2 */}
        <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-sm flex items-center justify-between">
          <div>
            <span className="text-xs text-slate-400 font-semibold uppercase tracking-wider block">Average Mood</span>
            <div className="text-2xl font-bold text-slate-800 mt-1">
              {avgMood}<span className="text-sm font-medium text-slate-400">/10</span>
            </div>
            <span className="text-[10px] text-emerald-600 mt-0.5 block font-medium">Goal: above 7.0</span>
          </div>
          <div className="w-10 h-10 bg-emerald-50 border border-emerald-100 rounded-xl flex items-center justify-center text-emerald-600 shrink-0">
            <span className="text-lg">😊</span>
          </div>
        </div>

        {/* Metric 3 */}
        <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-sm flex items-center justify-between">
          <div>
            <span className="text-xs text-slate-400 font-semibold uppercase tracking-wider block">Stress Rating</span>
            <div className="text-2xl font-bold text-slate-800 mt-1">
              {avgStress}<span className="text-sm font-medium text-slate-400">/10</span>
            </div>
            <span className={`text-[10px] uppercase font-bold mt-0.5 block ${parseFloat(avgStress) >= 7 ? "text-red-500" : "text-amber-500"}`}>
              {parseFloat(avgStress) >= 7 ? "High Vigilance" : "Adaptive Stress"}
            </span>
          </div>
          <div className="w-10 h-10 bg-amber-50 border border-amber-100 rounded-xl flex items-center justify-center text-amber-600 shrink-0">
            <Activity className="w-5 h-5 animate-pulse" />
          </div>
        </div>

        {/* Metric 4 */}
        <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-sm flex items-center justify-between">
          <div>
            <span className="text-xs text-slate-400 font-semibold uppercase tracking-wider block">Burnout Risk</span>
            <div className="text-2xl font-bold text-slate-800 mt-1">{currentBurnoutRisk}%</div>
            <span className="text-[10px] text-slate-400 mt-0.5 block">Most recent survey</span>
          </div>
          <div className={`w-10 h-10 border rounded-xl flex items-center justify-center shrink-0 ${getBurnoutColor(currentBurnoutRisk)}`}>
            {currentBurnoutRisk > 60 ? "🔥" : currentBurnoutRisk > 30 ? "⚡" : "🟢"}
          </div>
        </div>
      </div>

      {/* Main Beautiful Bento Grid */}
      {screenReaderMode ? (
        <div className="space-y-6">
          {/* Section 1: Accessible Overview Banner */}
          <div className="bg-slate-950 text-white p-6 rounded-3xl shadow-sm border border-slate-900">
            <div className="flex items-center gap-2 mb-3">
              <span className="text-[10px] font-extrabold bg-indigo-500 text-white px-2.5 py-1 rounded font-mono uppercase">WCAG AAA ACCESSIBILITY MODE</span>
            </div>
            <h3 className="text-base font-extrabold tracking-tight">Chronological Diagnostic Text Matrix</h3>
            <p className="text-xs text-slate-350 leading-relaxed mt-1">
              Your historical stress metrics, emotional factors, and detected self-regulation challenges compiled into a clean semantic data layout for voice-over screen readers and keyboard-only aspirants.
            </p>
          </div>

          {/* Section 2: Unified Chronology Table */}
          <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm">
            <h3 className="font-extrabold text-slate-800 text-xs uppercase tracking-wider mb-4">1. Chronological Trend Log</h3>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse" aria-label="Aspirant Mood Trends Chronology Table">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50 text-slate-500 font-bold uppercase font-mono">
                    <th className="py-3 px-4">Date</th>
                    <th className="py-3 px-4">Milestone Prep Focus</th>
                    <th className="py-3 px-4">Mood Rating (1-10)</th>
                    <th className="py-3 px-4">Stress Level (1-10)</th>
                    <th className="py-3 px-4">Burnout Risk</th>
                    <th className="py-3 px-4">Detected Thought Distortions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-slate-700">
                  {[...analyzedEntries].reverse().map((e, idx) => (
                    <tr key={idx} className="hover:bg-slate-50/50 transition-colors">
                      <td className="py-3.5 px-4 font-mono font-bold text-indigo-700">{e.date}</td>
                      <td className="py-3.5 px-4 font-bold text-slate-850">{e.exam}</td>
                      <td className="py-3.5 px-4 font-mono">{e.analysis?.moodScore} / 10</td>
                      <td className="py-3.5 px-4 font-mono">{e.analysis?.stressLevel} / 10</td>
                      <td className="py-3.5 px-4 font-mono font-bold text-slate-800">{e.analysis?.burnoutRisk}%</td>
                      <td className="py-3.5 px-4 text-slate-500 font-medium">
                        {e.analysis?.cognitiveDistortions && e.analysis.cognitiveDistortions.length > 0 
                          ? e.analysis.cognitiveDistortions.join(", ") 
                          : "None Registered"}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Section 3: Detailed Breakdown Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Thought Distortions List */}
            <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm">
              <h3 className="font-extrabold text-slate-800 text-xs uppercase tracking-wider mb-4">2. Thought Bias Diagnostic</h3>
              {distortionData.length === 0 ? (
                <p className="text-xs text-slate-400 font-mono italic">No distortion metrics registered.</p>
              ) : (
                <ol className="divide-y divide-slate-100 text-xs text-slate-700 space-y-3" aria-label="Registered cognitive patterns list">
                  {distortionData.map((d, i) => (
                    <li key={i} className="pt-3 flex justify-between items-center font-medium">
                      <span className="text-slate-800">{d.name}</span>
                      <span className="font-mono text-xs bg-slate-100 text-slate-600 px-3 py-1 rounded-xl font-bold">
                        Detected: {d.value} sessions
                      </span>
                    </li>
                  ))}
                </ol>
              )}
            </div>

            {/* Stress triggers list */}
            <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm">
              <h3 className="font-extrabold text-slate-800 text-xs uppercase tracking-wider mb-4">3. Isolation Trigger Frequencies</h3>
              {triggerData.length === 0 ? (
                <p className="text-xs text-slate-400 font-mono italic">Insufficient logs analyzed.</p>
              ) : (
                <ol className="divide-y divide-slate-100 text-xs text-slate-700 space-y-3" aria-label="Vulnerability trigger list">
                  {triggerData.map((tr, i) => (
                    <li key={i} className="pt-3 flex justify-between items-center font-medium">
                      <span className="text-slate-800">{tr.name}</span>
                      <span className="font-mono text-xs bg-indigo-50 border border-indigo-100 text-indigo-700 px-3 py-1 rounded-xl font-bold">
                        Encountered {tr.count} times
                      </span>
                    </li>
                  ))}
                </ol>
              )}
            </div>
          </div>

          {/* Section 4: Adaptive Coping Step list */}
          <div className="bg-indigo-50/50 p-6 border border-indigo-100 rounded-3xl">
            <h3 className="font-extrabold text-indigo-950 text-xs uppercase tracking-wider mb-3">4. Tailored Coping Step-by-Step Directions</h3>
            <p className="text-xs text-indigo-800 font-bold mb-4">
              Practice Title: &quot;{suggestedStrategy.title}&quot; ({suggestedStrategy.type}) — Difficulty level {suggestedStrategy.difficulty}
            </p>
            <ol className="list-decimal pl-5 space-y-2.5 text-xs text-indigo-900 leading-relaxed font-semibold">
              {suggestedStrategy.steps.map((st, i) => (
                <li key={i}>{st}</li>
              ))}
            </ol>
          </div>
        </div>
      ) : (
        <>
          <div className="grid grid-cols-12 gap-5">
        
        {/* Grid Item 1: Mood & Stress Trend (Large, span-8) */}
        <div className="col-span-12 lg:col-span-8 bg-white rounded-3xl border border-slate-100 p-6 shadow-sm flex flex-col justify-between">
          <div className="flex justify-between items-center mb-6">
            <div>
              <h3 className="font-bold text-slate-800 text-sm flex items-center gap-2">
                <Activity className="w-4 h-4 text-indigo-600" />
                Mood &amp; Stress Trend Stability
              </h3>
              <p className="text-[11px] text-slate-400 mt-0.5 font-medium">Tracking variance over daily mock study intervals</p>
            </div>
            <span className="px-2.5 py-1 bg-slate-50 border border-slate-100 text-[9px] font-mono font-bold text-slate-500 rounded uppercase">7-Day Horizon</span>
          </div>

          <div className="h-56 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={trendData} margin={{ top: 10, right: 10, left: -25, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorMood" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.15} />
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="colorStress" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#f43f5e" stopOpacity={0.15} />
                    <stop offset="95%" stopColor="#f43f5e" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="date" tick={{ fontSize: 9, fill: "#64748b" }} axisLine={false} tickLine={false} />
                <YAxis domain={[1, 10]} tick={{ fontSize: 9, fill: "#64748b" }} axisLine={false} tickLine={false} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "#1e293b",
                    borderRadius: "12px",
                    border: "none",
                    color: "#ffffff",
                    fontSize: "11px",
                  }}
                />
                <Area
                  type="monotone"
                  dataKey="mood"
                  name="Mood (Joy)"
                  stroke="#10b981"
                  strokeWidth={2.5}
                  fill="url(#colorMood)"
                />
                <Area
                  type="monotone"
                  dataKey="stress"
                  name="Stress Level"
                  stroke="#f43f5e"
                  strokeWidth={2.5}
                  strokeDasharray="4 4"
                  fill="url(#colorStress)"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>

          <div className="flex justify-between mt-4 text-[10px] text-slate-400 font-semibold font-mono tracking-tight pt-2 border-t border-slate-50">
            <span>START REHEARSAL</span>
            <span className="text-indigo-600">SYLLABUS WORKFLOW ACTIVE</span>
            <span>END POINT</span>
          </div>
        </div>

        {/* Grid Item 2: AI Insights (Gradients, span-4) */}
        <div className="col-span-12 lg:col-span-4 bg-gradient-to-br from-indigo-600 to-violet-700 rounded-3xl p-6 text-white shadow-xl shadow-indigo-100/50 flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="w-8 h-8 bg-white/10 rounded-xl flex items-center justify-center shrink-0">
                <Sparkles className="w-4 h-4 text-white" />
              </div>
              <h3 className="font-bold text-sm tracking-tight">AI Insights &amp; Synthesis</h3>
            </div>
            <p className="text-indigo-100 text-xs leading-relaxed mb-4 font-sans">
              Your recent entries mention <span className="font-bold text-white">"{triggerData[0]?.name || "Syllabus pressure"}"</span> and <span className="font-bold text-white">"{triggerData[1]?.name || "Mock timing"}"</span>. This correlates with physical stress markers.
            </p>
          </div>

          <div className="space-y-3 mt-4">
            <div className="p-3 bg-white/10 rounded-2xl border border-white/10">
              <p className="text-[9px] uppercase tracking-wider text-indigo-200 mb-1 font-mono font-bold">Dominant Thought Bias</p>
              <p className="text-xs font-semibold">
                {distortionData[0]?.name || "Healthy Cognitive Formulation"}
              </p>
            </div>
            <div className="p-3 bg-white/10 rounded-2xl border border-white/10 text-[10.5px] text-indigo-100">
              Score fluctuations detected are normal coping variance markers. Avoid evening mock sprints.
            </div>
          </div>
        </div>

        {/* Grid Item 3: Contextual Coping Strategy (span-5) */}
        <div className="col-span-12 lg:col-span-5 bg-white rounded-3xl border border-slate-100 p-6 shadow-sm flex flex-col justify-between">
          <div>
            <h3 className="font-bold text-slate-800 text-sm mb-4 flex items-center gap-2">
              🕊️ Suggested Coping Strategy
            </h3>
            <div className="flex gap-4 items-start mb-4">
              <div className="w-12 h-12 bg-indigo-50 border border-indigo-100 rounded-2xl flex items-center justify-center shrink-0 font-bold text-xl">
                🧘
              </div>
              <div>
                <p className="font-semibold text-slate-900 text-sm">{suggestedStrategy.title}</p>
                <p className="text-xs text-slate-500 mt-1">
                  Proven exercises of high efficacy to clear brain fatigue before study blocks.
                </p>
              </div>
            </div>

            <div className="bg-slate-50/50 p-3.5 rounded-2xl border border-slate-100 space-y-2 mt-2">
              <span className="text-[10px] font-mono font-bold text-slate-400 block uppercase tracking-wider">Exercise Steps:</span>
              {suggestedStrategy.steps.slice(0, 3).map((st, i) => (
                <div key={i} className="text-xs text-slate-600 flex items-start gap-1.5 leading-normal">
                  <span className="text-indigo-500 font-bold font-mono text-[10px] shrink-0">{i+1}.</span>
                  <span>{st}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-6 pt-4 border-t border-slate-100 flex justify-between text-center">
            <div>
              <p className="text-base font-bold text-slate-800">{suggestedStrategy.durationMinutes}m</p>
              <p className="text-[9px] text-slate-400 uppercase tracking-wider font-mono font-bold">Estimated Time</p>
            </div>
            <div>
              <p className="text-base font-bold text-slate-800">{suggestedStrategy.difficulty}</p>
              <p className="text-[9px] text-slate-400 uppercase tracking-wider font-mono font-bold">Level State</p>
            </div>
            <div>
              <p className="text-base font-bold text-slate-800">CBT Core</p>
              <p className="text-[9px] text-slate-400 uppercase tracking-wider font-mono font-bold">Heuristic Block</p>
            </div>
          </div>
        </div>

        {/* Grid Item 4: Stress Level SVG Gauge (span-3) */}
        <div className="col-span-12 md:col-span-6 lg:col-span-3 bg-amber-50/65 rounded-3xl border border-amber-100 p-6 flex flex-col items-center justify-center shrink-0 text-center shadow-sm">
          <div className="relative w-28 h-28">
            <svg className="w-full h-full transform -rotate-90">
              <circle cx="56" cy="56" r="44" stroke="currentColor" strokeWidth="8.5" fill="transparent" className="text-amber-100" />
              <circle cx="56" cy="56" r="44" stroke="currentColor" strokeWidth="8.5" fill="transparent" strokeDasharray="276.4" strokeDashoffset={276.4 - (276.4 * stressVal) / 10} className="text-amber-500 transition-all duration-500 rounded-full" />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <span className="text-3xl font-extrabold text-amber-950 font-mono tracking-tight">{stressVal}</span>
              <span className="text-[9px] text-amber-700 font-bold uppercase tracking-widest font-mono">Stress Index</span>
            </div>
          </div>
          <p className="mt-4 text-xs font-bold text-amber-900 uppercase tracking-wider">
            {stressVal >= 7 ? "High Vigilance" : "Reflexive Tension"}
          </p>
          <p className="text-[10px] text-amber-700/80 leading-normal max-w-[140px] mt-1.5 font-medium/40">
            Sustained cognitive and physical study feedback.
          </p>
        </div>

        {/* Grid Item 5: Locked Snippet of last diary entry (span-4) */}
        <div className="col-span-12 md:col-span-6 lg:col-span-4 bg-white rounded-3xl border border-slate-100 p-6 shadow-sm overflow-hidden flex flex-col justify-between">
          <div>
            <h3 className="font-bold text-slate-800 text-sm mb-3 flex items-center gap-1.5">
              <span>🔐 Encrypted Diary Fragment</span>
            </h3>
            <div className="relative p-3.5 bg-slate-50/80 rounded-2xl border border-slate-100 mt-2">
              <div className="absolute left-0 top-3 bottom-3 w-1 bg-violet-600 rounded-full"></div>
              <p className="pl-4 text-[9px] text-slate-400 italic font-mono select-none tracking-widest break-all leading-normal">
                {recentEntry?.encryptedText ? recentEntry.encryptedText.substring(0, 160) : "Raw string block cipher verification active."}
              </p>
            </div>
          </div>
          <div className="pt-4 border-t border-slate-50 flex items-center justify-between">
            <span className="text-[10px] text-slate-400 font-mono font-medium">AES-256 Enabled</span>
            <span className="text-[9.5px] bg-slate-100 text-slate-600 font-bold px-2 py-0.5 rounded font-mono uppercase">CIPHER SHIELD</span>
          </div>
        </div>

      </div>

      {/* Grid Row 2: Hidden Triggers and Cognitive Distortions details */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-2">
        {/* Distortions details */}
        <div className="bg-white rounded-3xl border border-slate-100 p-6 shadow-sm">
          <h3 className="text-sm font-bold text-slate-800 mb-4 flex items-center gap-1.5">
            <span className="text-lg">🧠</span>
            Identified Thought Distortions Frequency
          </h3>
          {distortionData.length === 0 ? (
            <div className="h-44 flex items-center justify-center text-xs text-slate-400 font-mono">
              Pure diagnostic clarity. Keep journaling.
            </div>
          ) : (
            <div className="space-y-4.5 max-h-44 overflow-y-auto pr-1">
              {distortionData.map((d, i) => (
                <div key={i} className="flex items-center justify-between">
                  <div className="flex flex-col">
                    <span className="text-xs font-semibold text-slate-700">{d.name}</span>
                    <span className="text-[10px] text-slate-400 font-medium">Mapped in raw writing threads</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-32 bg-slate-100 rounded-full h-2 overflow-hidden shrink-0">
                      <div
                        className="bg-indigo-600 h-2 rounded-full"
                        style={{ width: `${Math.min(100, (d.value / totalLogs) * 100)}%` }}
                      ></div>
                    </div>
                    <span className="text-xs font-bold font-mono text-slate-800">{d.value}</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Triggers Breakdown */}
        <div className="bg-white rounded-3xl border border-slate-100 p-6 shadow-sm">
          <h3 className="text-sm font-bold text-slate-800 mb-4 flex items-center gap-1.5">
            <span className="text-lg">📈</span>
            Top Performance &amp; Stress Drivers
          </h3>
          {triggerData.length === 0 ? (
            <div className="h-44 flex items-center justify-center text-xs text-slate-400 font-mono">
              Insufficient stats. Submit more journal snippets.
            </div>
          ) : (
            <div className="space-y-3">
              {triggerData.map((tr, index) => (
                <div key={index} className="flex items-center justify-between p-2.5 rounded-xl hover:bg-slate-50 transition-colors">
                  <div className="flex items-center gap-2.5">
                    <span className="w-6 h-6 rounded-lg bg-indigo-50 text-indigo-700 flex items-center justify-center text-[10px] font-bold font-mono">
                      #{index+1}
                    </span>
                    <span className="text-xs font-semibold text-slate-700">{tr.name}</span>
                  </div>
                  <span className="text-xs font-mono font-bold bg-indigo-50 text-indigo-700 border border-indigo-100 px-2.5 py-0.5 rounded-full select-none">
                    {tr.count} counts
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
      </>
      )}

    </div>
  );
}
