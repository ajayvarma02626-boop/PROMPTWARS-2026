/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from "react";
import { UnitTestResult } from "../types";
import { CheckCircle2, XCircle, Play, ShieldAlert, Sparkles, BookOpen, KeyRound, Loader2 } from "lucide-react";

export default function TestHarness() {
  const [testResults, setTestResults] = useState<UnitTestResult[]>([]);
  const [isRunning, setIsRunning] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");

  const fetchAndRunTests = async () => {
    setIsRunning(true);
    setErrorMsg("");
    try {
      const response = await fetch("/api/run-tests");
      if (!response.ok) {
        throw new Error(`Server returned HTTP ${response.status}`);
      }
      const data = await response.json();
      if (data && Array.isArray(data.tests)) {
        setTestResults(data.tests);
      } else {
        throw new Error("No tests returned from API.");
      }
    } catch (err: any) {
      console.error(err);
      setErrorMsg(err.message || "Failed to trigger backend unit tests.");
    } finally {
      setIsRunning(false);
    }
  };

  useEffect(() => {
    fetchAndRunTests();
  }, []);

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case "mood":
        return <Sparkles className="w-4 h-4 text-purple-500" />;
      case "triggers":
        return <BookOpen className="w-4 h-4 text-emerald-500" />;
      case "strategies":
        return <ShieldAlert className="w-4 h-4 text-amber-500" />;
      case "security":
        return <KeyRound className="w-4 h-4 text-sky-500" />;
      default:
        return null;
    }
  };

  return (
    <div id="test-harness" className="bg-white rounded-xl shadow-sm border border-neutral-200 overflow-hidden">
      <div className="p-5 border-b border-neutral-100 flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold text-neutral-800 flex items-center gap-2">
            <KeyRound className="w-5 h-5 text-indigo-600" />
            Integrity &amp; Test Suite
          </h2>
          <p className="text-xs text-neutral-500 mt-1">
            Validating mood classification, stress heuristics, coping adaptive models, and cryptographic loops.
          </p>
        </div>
        
        <button
          onClick={fetchAndRunTests}
          disabled={isRunning}
          aria-label="Run backend validation test suite for mood algorithms and cryptographic loops"
          className="flex items-center gap-2 px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-700 disabled:bg-neutral-300 text-white font-medium text-xs rounded-lg shadow-sm transition-all duration-150 cursor-pointer"
        >
          {isRunning ? (
            <>
              <Loader2 className="w-3.5 h-3.5 animate-spin" />
              Running Test Suite...
            </>
          ) : (
            <>
              <Play className="w-3.5 h-3.5" />
              Run Unit Tests
            </>
          )}
        </button>
      </div>

      <div className="p-5">
        {errorMsg && (
          <div className="p-3 bg-red-50 text-red-600 text-sm rounded-lg mb-4 flex items-center gap-2">
            <XCircle className="w-4 h-4 shrink-0" />
            {errorMsg}
          </div>
        )}

        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-5">
          <div className="p-3.5 rounded-lg bg-neutral-50 border border-neutral-100">
            <div className="text-xs text-neutral-500">Total Cases</div>
            <div className="text-xl font-bold font-mono text-neutral-800 mt-0.5">
              {testResults.length}
            </div>
          </div>
          <div className="p-3.5 rounded-lg bg-emerald-50/50 border border-emerald-100">
            <div className="text-xs text-emerald-600 font-medium">Passed</div>
            <div className="text-xl font-bold font-mono text-emerald-700 mt-0.5">
              {testResults.filter(r => r.status === "passed").length} / {testResults.length}
            </div>
          </div>
          <div className="p-3.5 rounded-lg bg-neutral-50 border border-neutral-100">
            <div className="text-xs text-neutral-500">Security Enc</div>
            <div className="text-xl font-bold font-mono text-sky-700 mt-0.5">
              AES-256
            </div>
          </div>
          <div className="p-3.5 rounded-lg bg-neutral-50 border border-neutral-100">
            <div className="text-xs text-neutral-500">Framework</div>
            <div className="text-xs font-semibold text-neutral-700 mt-1.5 truncate">
              Express + @google/genai
            </div>
          </div>
        </div>

        <div className="space-y-2.5">
          {isRunning ? (
            <div className="py-12 flex flex-col items-center justify-center text-neutral-400 gap-2">
              <Loader2 className="w-8 h-8 animate-spin text-indigo-600" />
              <div className="text-xs font-mono">Executing system assertions...</div>
            </div>
          ) : testResults.length === 0 ? (
            <div className="p-4 text-center text-xs text-neutral-400">
              No test data. Click the button to execute assertion routines.
            </div>
          ) : (
            testResults.map((result, idx) => (
              <div
                key={idx}
                className="p-3.5 rounded-lg border border-neutral-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:bg-neutral-50/50 transition-colors"
              >
                <div className="flex items-start gap-3">
                  <div className="mt-0.5">
                    {result.status === "passed" ? (
                      <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                    ) : (
                      <XCircle className="w-5 h-5 text-rose-500" />
                    )}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-medium text-sm text-neutral-800">
                        {result.testName}
                      </span>
                      <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[10px] font-mono capitalize bg-neutral-100 text-neutral-600">
                        {getCategoryIcon(result.category)}
                        {result.category}
                      </span>
                    </div>
                    <p className="text-xs text-neutral-500 mt-1 leading-relaxed">
                      {result.message}
                    </p>
                  </div>
                </div>

                <div className="shrink-0 self-end sm:self-center">
                  <span
                    className={`inline-flex px-2 py-0.5 rounded-full text-xs font-mono font-medium ${
                      result.status === "passed"
                        ? "bg-emerald-50 text-emerald-700 border border-emerald-200"
                        : "bg-rose-50 text-rose-700 border border-rose-200"
                    }`}
                  >
                    {result.status.toUpperCase()}
                  </span>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
