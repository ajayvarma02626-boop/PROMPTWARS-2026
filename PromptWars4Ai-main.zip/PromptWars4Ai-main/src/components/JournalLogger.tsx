/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, FormEvent, useEffect } from "react";
import { JournalEntry, ExamType, CopingStrategy } from "../types";
import { 
  BookOpen, Calendar, HelpCircle, Key, KeyRound, Loader2, PlayCircle, 
  Sparkles, CheckCircle2, ShieldCheck, Volume2, Square, Info, ChevronRight, Eye, EyeOff
} from "lucide-react";

interface JournalLoggerProps {
  entries: JournalEntry[];
  onAddEntry: (entry: JournalEntry) => void;
  onUpdateEntry: (id: string, updated: Partial<JournalEntry>) => void;
  lang?: "en" | "hi" | "hinglish";
}

const loggerTranslations: Record<"en" | "hi" | "hinglish", Record<string, string>> = {
  en: {
    newJournalHeader: "New Daily Emotional Journal",
    examLabel: "Target High-Stakes Milestone Exam",
    promptSuggest: "Empathetic Prompt:",
    promptBody: "How are your mock exam percentage rates looking today? Are you neglecting sleep or comparing your progress to fellow competition candidates? Write freely below.",
    textareaLabel: "Daily Open-Ended Log (Be completely raw & honest)",
    placeholderText: "Ex. Today's GATE engineering math session felt absolutely brutal. I scored a 50 percentile in my mock test and I am terrified that I have forgotten everything from the core topics. UPSC current affairs are stressing me out too...",
    charCount: "characters typed",
    encryptionMsg: "AES-256 Server-side encryption active",
    buttonEvaluate: "Evaluate & Encrypt Private Diary",
    buttonEvaluating: "Psychological Stress Mining Active...",
    previousLogsHeader: "Previous Secured Journal Entries",
    emptyStorage: "Your secure storage is currently empty. Start logging to persist stress triggers isonymically.",
    decryptBtn: "Decrypt securely via AES-256 Key",
    hideBtn: "Hide Plain Text",
    moodLevel: "Mood Level",
    stressIndex: "Stress Index",
    burnoutRisk: "Burnout Risk",
    triggersLabel: "Triggers:",
    reportHeader: "Psychological Wellness Report",
    realtimeAnalysisBadge: "Real-time Analysis",
    noReportYet: "No journal submitted yet. Fill out the daily emotional log to see the report format.",
    reportLoading: "Querying local Gemini model parameters and applying AES CBC encryption block...",
    reportFail: "Failed to finalize analysis on this entry. Please verify details and try again.",
    assistantBadge: "Dynamic Wellness Assistant",
    stopSpeech: "Stop Speech",
    speechRead: "Read Out Loud",
    speechTip: "Click Reader icon to listen in English/Hindi dialect.",
    burnoutFatigue: "Burnout Fatigue",
    dominantEmotions: "Dominant Emotions",
    emotionsLabel: "Mapped from raw journaling nuances.",
    distortionsHeader: "Found Cognitive Distortions",
    distortionTip: "Cognitive biases that increase exam anxiety. Challenge this thought during mock reviews.",
    copingExercisesHeader: "Tailored Coping Exercises",
    techniqueLabel: "Technique Type:",
    academicPatternHeader: "Academic Core Pattern:",
    forgotPinLink: "Forgot PIN or locked out? Reset PIN settings",
  },
  hi: {
    newJournalHeader: "नया दैनिक भावनात्मक जर्नल",
    examLabel: "लक्षित उच्च-तनाव मुख्य परीक्षा चुनें",
    promptSuggest: "संवेदनशील संकेत:",
    promptBody: "आज आपके मॉक परीक्षा अंक कैसे लग रहे हैं? क्या आप नींद की उपेक्षा कर रहे हैं या अपनी प्रगति की तुलना अन्य उम्मीदवारों से कर रहे हैं? नीचे स्वतंत्र रूप से लिखें।",
    textareaLabel: "दैनिक खुला लॉग (पूरी तरह से सच्चे और ईमानदार रहें)",
    placeholderText: "उदा. आज का गेट परीक्षा इंजीनियरिंग गणित सत्र बहुत कठिन लगा। मैंने अपने मॉक टेस्ट में केवल 50 प्रतिशत अंक प्राप्त किए और मैं डरा हुआ हूं। यूपीएससी करंट अफेयर्स भी मुझे तनाव दे रहे हैं...",
    charCount: "अक्षर लिखे गए",
    encryptionMsg: "AES-256 सर्वर-साइड एन्क्रिप्शन सक्रिय",
    buttonEvaluate: "निजी डायरी का मूल्यांकन और एन्क्रिप्ट करें",
    buttonEvaluating: "मनोवैज्ञानिक तनाव माइनिंग सक्रिय...",
    previousLogsHeader: "पिछले सुरक्षित जर्नल प्रविष्टियां",
    emptyStorage: "आपका सुरक्षित स्टोरेज वर्तमान में खाली है। अनाम रूप से तनाव ट्रिगर्स रिकॉर्ड करना शुरू करें।",
    decryptBtn: "AES-256 कुंजी से सुरक्षित रूप से डिक्रिप्ट करें",
    hideBtn: "सादा टेक्स्ट छुपाएं",
    moodLevel: "मनोदशा स्तर",
    stressIndex: "तनाव सूचकांक",
    burnoutRisk: "बर्नआउट जोखिम",
    triggersLabel: "ट्रिगर्स:",
    reportHeader: "मनोवैज्ञानिक कल्याण रिपोर्ट",
    realtimeAnalysisBadge: "रीयल-टाइम विश्लेषण",
    noReportYet: "अभी तक कोई जर्नल जमा नहीं किया गया है। रिपोर्ट देखने के लिए दैनिक भावनात्मक लॉग भरें।",
    reportLoading: "जेमिनी मॉडल मापदंडों को क्वेरी करना और एईएस सीबीसी एन्क्रिप्शन लागू करना...",
    reportFail: "इस प्रविष्टि पर विश्लेषण पूरा करने में विफल। कृपया विवरण सत्यापित करें और पुनः प्रयास करें।",
    assistantBadge: "गतिशीलता स्वास्थ्य सहायक",
    stopSpeech: "आवाज रोकें",
    speechRead: "ज़ोर से पढ़ें",
    speechTip: "अंग्रेजी/हिंदी बोली में सुनने के लिए रीडर आइकन पर क्लिक करें।",
    burnoutFatigue: "बर्नआउट थकान",
    dominantEmotions: "प्रमुख भावनाएं",
    emotionsLabel: "जर्नलिंग की सूक्ष्मताओं से मैप किया गया।",
    distortionsHeader: "संज्ञानात्मक विकृति (Cognitive Distortions) मिली",
    distortionTip: "संज्ञानात्मक पूर्वाग्रह जो परीक्षा की चिंता बढ़ाते हैं। मॉक टेस्ट की समीक्षा के दौरान इस विचार को चुनौती दें।",
    copingExercisesHeader: "अनुकूलित मुकाबला अभ्यास (Coping Exercises)",
    techniqueLabel: "तकनीक का प्रकार:",
    academicPatternHeader: "अकादमिक मूल पैटर्न:",
    forgotPinLink: "पिन भूल गए या लॉक हो गए? पिन सेटिंग्स रीसेट करें",
  },
  hinglish: {
    newJournalHeader: "New Daily Emotional Journal",
    examLabel: "Target Exam Prep Category",
    promptSuggest: "Empathetic Prompt Suggestions:",
    promptBody: "Aaj ke mock test percentile marks kaise rahe? Sleep neglect ho rahi hai ya competitors se compare karke negative feel ho raha hai? Likhein bina kisi dar ke.",
    textareaLabel: "Daily Open Log (Be fully raw and honest with yourself)",
    placeholderText: "Ex. Aaj UPSC current affairs and GATE general aptitude test stress levels are off the limits. Score percentile decrease ho gaya mock test me, and complete lag raha hai ki main fail ho jaunga...",
    charCount: "characters likhe gaye",
    encryptionMsg: "Secure AES-256 Server-side encryption background me active",
    buttonEvaluate: "Evaluate & Encrypt Private Diary",
    buttonEvaluating: "Evaluating stress nodes with AI...",
    previousLogsHeader: "Aapke Secured Journal Logs",
    emptyStorage: "Secure storage empty hai. Status analyze karne ke liye daily stress inputs aur trigger points enter karein.",
    decryptBtn: "Securely Decrypt with AES-255 Key",
    hideBtn: "Plain Text Hide Karein",
    moodLevel: "Mood Status",
    stressIndex: "Stress Levels",
    burnoutRisk: "Burnout Pressure",
    triggersLabel: "Triggers Isolate Hue:",
    reportHeader: "AI Psychological Wellness Report",
    realtimeAnalysisBadge: "Live AI Mining",
    noReportYet: "Koi journal submit nahi kiya gaya. UI layout dekhne ke liye please daily wellness logs enter karein.",
    reportLoading: "Invoking secure backend API parameters and AES-256 cyclic algorithms...",
    reportFail: "Analysis validation failure. Ek baar checks verify karke, try again cursor settings.",
    assistantBadge: "Sahaya AI Assistant",
    stopSpeech: "Awaaz band karein",
    speechRead: "Bolkar sunayein",
    speechTip: "Clear English & Hindi voice playback ke liye speech button toggle karein.",
    burnoutFatigue: "Mental Burnout Factor",
    dominantEmotions: "Primary Emotions",
    emotionsLabel: "Determined from journaling sentiments.",
    distortionsHeader: "Mindset Biases (Cognitive Distortions)",
    distortionTip: "Thoughts jo stress and prep metrics ko pull down karte hain. Reviews ke samay consciously verify karein.",
    copingExercisesHeader: "Tailored Coping Techniques",
    techniqueLabel: "CBT Exercise Category:",
    academicPatternHeader: "Prep Pattern Insights:",
    forgotPinLink: "Security PIN bhool gaye? Reset PIN settings",
  }
};

export default function JournalLogger({ entries, onAddEntry, onUpdateEntry, lang = "en" }: JournalLoggerProps) {
  const logT = loggerTranslations[lang];

  const [inputText, setInputText] = useState("");
  const [selectedExam, setSelectedExam] = useState<ExamType>("CAT");
  const [isLoading, setIsLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");
  
  // Decrypted cache for entries view
  const [decryptedTextCache, setDecryptedTextCache] = useState<Record<string, string>>({});
  const [showPlainHistoryId, setShowPlainHistoryId] = useState<string | null>(null);
  
  // System speech synthesis state
  const [speakingId, setSpeakingId] = useState<string | null>(null);

  // --- Secure Two-Step Verification (2SV) Suite States ---
  const [twoSvToken, setTwoSvToken] = useState<string | null>(null);
  const [show2SvPopup, setShow2SvPopup] = useState(false);
  const [twoSvStep, setTwoSvStep] = useState<"register_pin" | "enter_pin" | "enter_otp">("register_pin");
  const [isPinRegistered, setIsPinRegistered] = useState(false);
  const [pinValue, setPinValue] = useState("");
  const [otpValue, setOtpValue] = useState("");
  const [twoSvError, setTwoSvError] = useState("");
  const [twoSvSuccess, setTwoSvSuccess] = useState("");
  const [is2SvLoading, setIs2SvLoading] = useState(false);
  const [activeDecTask, setActiveDecTask] = useState<{ id: string; secValue: string } | null>(null);
  const [otpInfo, setOtpInfo] = useState<{ maskedEmail: string; debugOtp?: string } | null>(null);
  
  // PIN Visibility toggle
  const [showPin, setShowPin] = useState(false);

  // Cancel SpeechSynthesis when switching tabs or unmounting
  useEffect(() => {
    return () => {
      if ("speechSynthesis" in window) {
        window.speechSynthesis.cancel();
      }
    };
  }, []);

  const examsList: { value: ExamType; name: string; syllabusTip: string }[] = [
    { value: "CAT", name: "CAT (Management Aspirants)", syllabusTip: "Focusing on DILR speed, QA formulas, & High Percentile thresholds." },
    { value: "GATE", name: "GATE (Engineering Aspirants)", syllabusTip: "Struggling with virtual calculations, complex derivations, & syllabus depth." },
    { value: "UPSC", name: "UPSC (Civil Services Aspirants)", syllabusTip: "Facing extensive answer writing, vast general studies, & long timeline strain." },
    { value: "JEE", name: "JEE (Engineering Entrances)", syllabusTip: "Dealing with relative scaling, intensive chemistry equations, & coaching comparison." },
  ];

  // Text to Speech Helper using Web Speech Synthesis API (Offline-first & highly accessible)
  const speakText = (textToSpeak: string, id: string) => {
    if ("speechSynthesis" in window) {
      window.speechSynthesis.cancel(); // Stop anything else currently speaking
      
      if (speakingId === id) {
        setSpeakingId(null);
        return;
      }

      const utterance = new SpeechSynthesisUtterance(textToSpeak);
      
      // Attempt bilingual Hindi/English synthesis or choose general voice
      const voices = window.speechSynthesis.getVoices();
      const optimalVoice = voices.find(v => v.lang.includes("hi-IN") || v.lang.includes("en-IN") || v.lang.includes("en-US"));
      if (optimalVoice) {
        utterance.voice = optimalVoice;
      }
      
      utterance.onend = () => {
        setSpeakingId(null);
      };
      utterance.onerror = () => {
        setSpeakingId(null);
      };

      setSpeakingId(id);
      window.speechSynthesis.speak(utterance);
    } else {
      alert("TTS is not supported in this browser environment.");
    }
  };

  const stopSpeaking = () => {
    if ("speechSynthesis" in window) {
      window.speechSynthesis.cancel();
      setSpeakingId(null);
    }
  };

  // Submit Logger
  const handleSubmitLog = async (e: FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;

    setIsLoading(true);
    setErrorMsg("");

    const newJournalId = "journal-" + Date.now();
    const currentDateString = new Date().toISOString().split("T")[0];

    // Build immediate pending entry
    const localPendingEntry: JournalEntry = {
      id: newJournalId,
      date: currentDateString,
      exam: selectedExam,
      text: "Pending encryption and analysis...",
      moodScore: 5,
      analysis: null,
      status: "pending"
    };

    onAddEntry(localPendingEntry);

    try {
      const response = await fetch("/api/analyze-journal", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          text: inputText,
          exam: selectedExam,
          date: currentDateString
        })
      });

      if (!response.ok) {
        throw new Error(`Server endpoint responded with ${response.status}`);
      }

      const data = await response.json();
      
      // Update entry with real encrypted content and analysis
      onUpdateEntry(newJournalId, {
        encryptedText: data.encryptedText,
        text: `[AES-256 ENCRYPTED PERSISTENCE] (View Plain Text available below)`,
        moodScore: data.analysis?.moodScore || 5,
        analysis: data.analysis,
        status: "analyzed"
      });

      // Cache raw local text in memory so user sees it immediately without clicking decrypt
      setDecryptedTextCache(prev => ({
        ...prev,
        [newJournalId]: inputText
      }));
      setShowPlainHistoryId(newJournalId);

      setInputText("");

    } catch (err: any) {
      console.error(err);
      setErrorMsg(err.message || "Failed to reach AI Wellness Analyzer.");
      onUpdateEntry(newJournalId, {
        status: "error"
      });
    } finally {
      setIsLoading(false);
    }
  };

  // Primary trigger called when clicking Decrypt securely via AES-256 Key
  const decryptJournal = async (id: string, secValue?: string) => {
    if (!secValue) return;

    // Toggle display if already decrypted cache has it
    if (decryptedTextCache[id]) {
      setShowPlainHistoryId(showPlainHistoryId === id ? null : id);
      return;
    }

    // Step A: If we already have a valid unexpired 2SV Session token, attempt decryption immediately
    if (twoSvToken) {
      const success = await executeServerDecryption(id, secValue, twoSvToken);
      if (success) return;
    }

    // Step B: No active valid session. Initialize 2-Step Verification challenge sequence.
    setActiveDecTask({ id, secValue });
    setTwoSvError("");
    setTwoSvSuccess("");
    setPinValue("");
    setOtpValue("");
    setIs2SvLoading(true);

    try {
      const res = await fetch("/api/2sv-status");
      if (res.ok) {
        const data = await res.json();
        setIsPinRegistered(data.isPinSet);
        if (data.isPinSet) {
          setTwoSvStep("enter_pin");
        } else {
          setTwoSvStep("register_pin");
        }
        setShow2SvPopup(true);
      } else {
        alert("Unable to fetch security parameters from main decryptor.");
      }
    } catch (e) {
      console.error(e);
      alert("Error initiating secure 2SV channel connection.");
    } finally {
      setIs2SvLoading(false);
    }
  };

  // Helper doing the official secured backend decryption
  const executeServerDecryption = async (id: string, secValue: string, token: string): Promise<boolean> => {
    try {
      const response = await fetch("/api/decrypt-journal", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ encryptedText: secValue, token })
      });
      if (response.ok) {
        const bodyValue = await response.json();
        setDecryptedTextCache(prev => ({
          ...prev,
          [id]: bodyValue.text
        }));
        setShowPlainHistoryId(id);
        return true;
      } else {
        // Token might have expired or is invalid
        const errData = await response.json().catch(() => ({}));
        if (errData.error === "2sv_expired" || errData.error === "2sv_required") {
          setTwoSvToken(null); // Clear invalid token
        }
        return false;
      }
    } catch (e) {
      console.error("Cryptographic fetch error:", e);
      return false;
    }
  };

  // Action B1: Configure a brand new 6-digit backup PIN
  const handleRegisterPin = async () => {
    if (!/^\d{6}$/.test(pinValue)) {
      setTwoSvError("Security PIN must be exactly 6 numerical digits.");
      return;
    }
    setTwoSvError("");
    setIs2SvLoading(true);

    try {
      const res = await fetch("/api/register-2sv-pin", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ pin: pinValue })
      });
      const data = await res.json();
      if (res.ok) {
        setIsPinRegistered(true);
        setTwoSvSuccess("PIN successfully configured securely! Initializing dynamic OTP verification challenge...");
        // Prompt OTP generation immediately
        await dispatchOtpChallenge();
      } else {
        setTwoSvError(data.error || "Failed to set up PIN.");
      }
    } catch (e: any) {
      setTwoSvError("PIN setup exception: " + e.message);
    } finally {
      setIs2SvLoading(false);
    }
  };

  // Dispatch OTP Helper using the backend API
  const dispatchOtpChallenge = async () => {
    setTwoSvError("");
    setIs2SvLoading(true);
    try {
      const res = await fetch("/api/request-2sv-otp", {
        method: "POST",
        headers: { "Content-Type": "application/json" }
      });
      const data = await res.json();
      if (res.ok) {
        setOtpInfo({
          maskedEmail: data.maskedEmail,
          debugOtp: data.debugOtp
        });
        setTwoSvStep("enter_otp");
        setTwoSvSuccess("Two-Step Verification triggered: Passcode dispatched!");
      } else {
        setTwoSvError(data.error || "Failed to generate dynamic OTP.");
      }
    } catch (e: any) {
      setTwoSvError("OTP generation exception: " + e.message);
    } finally {
      setIs2SvLoading(false);
    }
  };

  // Action B2: Verify existing PIN, then request OTP
  const handleVerifyPinOnly = async () => {
    if (!/^\d{6}$/.test(pinValue)) {
      setTwoSvError("Please enter your 6-digit numerical PIN first.");
      return;
    }
    // Set step to enter_otp and fetch the OTP challenge
    await dispatchOtpChallenge();
  };

  // Action B3: Complete 2SV Check
  const handleVerify2SvComplete = async () => {
    if (!/^\d{6}$/.test(pinValue) || !/^\d{6}$/.test(otpValue)) {
      setTwoSvError("Verification requires both your valid 6-digit PIN and 6-digit OTP passcode.");
      return;
    }
    setTwoSvError("");
    setIs2SvLoading(true);

    try {
      const res = await fetch("/api/verify-2sv", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ pin: pinValue, otp: otpValue })
      });
      const data = await res.json();
      if (res.ok && data.token) {
        setTwoSvToken(data.token);
        setShow2SvPopup(false);
        setTwoSvSuccess("");
        
        // Success! Automatically trigger safe decryption for the requested journal
        if (activeDecTask) {
          await executeServerDecryption(activeDecTask.id, activeDecTask.secValue, data.token);
          setActiveDecTask(null);
        }
      } else {
        setTwoSvError(data.error || "Authentication failed. Incorrect PIN or OTP code.");
      }
    } catch (e: any) {
      setTwoSvError("2SV check failure: " + e.message);
    } finally {
      setIs2SvLoading(false);
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6" id="journal-section">
      
      {/* Column A: Journal Entry Box (7/12) */}
      <div className="lg:col-span-7 space-y-6">
        <div className="bg-white rounded-3xl border border-slate-100 p-6 shadow-sm shadow-slate-100/50">
          <div className="flex items-center gap-2 mb-5">
            <BookOpen className="w-5 h-5 text-indigo-600" />
            <h2 className="text-base font-extrabold text-slate-900 tracking-tight">{logT.newJournalHeader}</h2>
          </div>

          <form onSubmit={handleSubmitLog} className="space-y-5">
            {/* Exam category select */}
            <div>
              <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">
                {logT.examLabel}
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {(["CAT", "GATE", "UPSC", "JEE"] as ExamType[]).map((exam) => (
                  <button
                    key={exam}
                    type="button"
                    onClick={() => setSelectedExam(exam)}
                    className={`px-3 py-2.5 border rounded-xl text-xs font-bold uppercase text-center transition-all cursor-pointer ${
                      selectedExam === exam
                        ? "bg-indigo-600 text-white border-indigo-600 shadow-md shadow-indigo-100"
                        : "bg-white text-slate-600 border-slate-200 hover:border-slate-350 hover:bg-slate-50"
                    }`}
                  >
                    {exam}
                  </button>
                ))}
              </div>
              <p className="text-[10px] text-slate-400 mt-2 font-medium italic">
                {examsList.find(e => e.value === selectedExam)?.syllabusTip}
              </p>
            </div>

            {/* Prompt Suggestion / Anchor */}
            <div className="bg-indigo-50/30 rounded-2xl p-4 border border-indigo-100/30 flex items-start gap-3">
              <span className="text-lg mt-0.5 shrink-0">💡</span>
              <div className="text-xs text-slate-600 leading-relaxed font-sans">
                <strong>{logT.promptSuggest}</strong> {logT.promptBody}
              </div>
            </div>

            {/* Textarea */}
            <div>
              <label htmlFor="journal-textarea" className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">
                {logT.textareaLabel}
              </label>
              <textarea
                id="journal-textarea"
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                placeholder={logT.placeholderText}
                rows={5}
                required
                className="w-full text-sm p-4 bg-slate-50/50 hover:bg-slate-50 focus:bg-white border border-slate-200 focus:border-indigo-500 focus:outline-none rounded-2xl transition-colors resize-y leading-relaxed text-slate-800"
              />
              <div className="flex items-center justify-between mt-1.5 text-[10px] text-slate-400 font-mono">
                <span>{inputText.length} {logT.charCount}</span>
                <span className="flex items-center gap-1 font-semibold text-indigo-600/80">
                  <ShieldCheck className="w-3.5 h-3.5" />
                  {logT.encryptionMsg}
                </span>
              </div>
            </div>

            {errorMsg && (
              <div className="p-4 bg-red-50 text-red-700 text-xs rounded-2xl border border-red-100/30 font-semibold leading-relaxed">
                {errorMsg}
              </div>
            )}

            {/* Submit button */}
            <button
              type="submit"
              disabled={isLoading || !inputText.trim()}
              className="w-full py-3 bg-indigo-600 hover:bg-indigo-700 text-white disabled:bg-slate-200 disabled:text-slate-400 font-extrabold text-xs rounded-2xl transition-all flex items-center justify-center gap-2 cursor-pointer shadow-md shadow-indigo-100/30"
            >
              {isLoading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin text-white" />
                  {logT.buttonEvaluating}
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 text-amber-300 fill-amber-300 animate-pulse" />
                  {logT.buttonEvaluate}
                </>
              )}
            </button>
          </form>
        </div>

        {/* Column A Part 2: Journal Entry logs index */}
        <div className="space-y-4">
          <h3 className="text-sm font-bold text-neutral-700 flex items-center gap-1.5">
            <Calendar className="w-4 h-4 text-neutral-500" />
            {logT.previousLogsHeader} ({entries.length})
          </h3>

          {entries.length === 0 ? (
            <div className="p-10 bg-white border border-slate-100 rounded-3xl text-center text-xs text-slate-400">
              {logT.emptyStorage}
            </div>
          ) : (
            <div className="space-y-4">
              {[...entries]
                .reverse()
                .map((entry) => {
                  const isAnalyzed = entry.status === "analyzed" && entry.analysis;
                  const isDecrypted = decryptedTextCache[entry.id];
                  const isOpen = showPlainHistoryId === entry.id;

                  return (
                    <div
                      key={entry.id}
                      className="bg-white rounded-3xl border border-slate-100/80 shadow-sm p-5 transition-all overflow-hidden hover:border-slate-200"
                    >
                      {/* Entry header */}
                      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-50 pb-3 mb-3.5 text-xs text-slate-500">
                        <div className="flex items-center gap-2">
                          <span className="font-mono text-[10px] bg-slate-100 px-2.5 py-1 rounded text-slate-600 font-bold">
                            {entry.date}
                          </span>
                          <span className="px-2.5 py-1 bg-indigo-50 border border-indigo-100 text-indigo-700 font-bold rounded-lg font-sans uppercase">
                            {entry.exam}
                          </span>
                        </div>

                        <div className="flex items-center gap-2">
                          {entry.status === "pending" ? (
                            <span className="flex items-center gap-1 text-amber-500 font-mono text-[10px] font-bold">
                              <Loader2 className="w-3 h-3 animate-spin" /> Mining state...
                            </span>
                          ) : entry.status === "error" ? (
                            <span className="text-rose-500 font-bold font-mono text-[10px]">⚠️ Fail</span>
                          ) : (
                            <span className="flex items-center gap-0.5 text-emerald-600 font-mono font-bold text-[10px]">
                              <CheckCircle2 className="w-3.5 h-3.5 inline text-emerald-500" /> Encrypt-analyzed
                            </span>
                          )}
                        </div>
                      </div>

                      {/* Displayed content */}
                      <div className="space-y-3.5">
                        <div className="text-xs text-slate-600 p-4 bg-slate-50/50 rounded-2xl border border-slate-100 relative">
                          <div className="space-y-2">
                            {isOpen && isDecrypted ? (
                              <p className="font-semibold text-slate-800 leading-relaxed font-sans italic">
                                &quot;{decryptedTextCache[entry.id]}&quot;
                              </p>
                            ) : (
                              <div className="text-slate-400 font-mono text-[10px] space-y-1.5 antialiased select-none tracking-widest break-all leading-relaxed">
                                {entry.encryptedText 
                                  ? `${entry.encryptedText.substring(0, 75)}... [AES-256 SECURED PERSISTENCE]`
                                  : "Raw plain text blocked by encryption parameters."}
                              </div>
                            )}

                            {entry.encryptedText && (
                              <button
                                onClick={() => decryptJournal(entry.id, entry.encryptedText)}
                                className="inline-flex items-center gap-1 text-[10px] font-mono text-indigo-600 hover:text-indigo-800 font-bold transition-all mt-1 bg-white border border-neutral-200 px-2.5 py-1 rounded cursor-pointer"
                              >
                                {isOpen && isDecrypted ? (
                                  <>
                                    <EyeOff className="w-3 h-3 text-indigo-600" />
                                    Hide Plain Text
                                  </>
                                ) : (
                                  <>
                                    <Eye className="w-3 h-3 text-indigo-600" />
                                    Decrypt securely via AES-256 Key
                                  </>
                                )}
                              </button>
                            )}
                          </div>
                        </div>

                        {/* Analysis Indicators (Quick inline parameters) */}
                        {isAnalyzed && (
                          <div className="grid grid-cols-3 gap-2 text-center pt-1 border-t border-dashed border-neutral-100">
                            <div className="p-1.5 bg-neutral-50 rounded">
                              <span className="text-[9px] text-neutral-400 block font-medium">Mood Level</span>
                              <span className="text-xs font-bold font-mono text-neutral-700">
                                {entry.analysis?.moodScore} / 10
                              </span>
                            </div>
                            <div className="p-1.5 bg-neutral-50 rounded">
                              <span className="text-[9px] text-neutral-400 block font-medium">Stress Index</span>
                              <span className="text-xs font-bold font-mono text-red-500">
                                {entry.analysis?.stressLevel} / 10
                              </span>
                            </div>
                            <div className="p-1.5 bg-neutral-50 rounded">
                              <span className="text-[9px] text-neutral-400 block font-medium">Burnout Risk</span>
                              <span className="text-xs font-bold font-mono text-amber-600">
                                {entry.analysis?.burnoutRisk}%
                              </span>
                            </div>
                          </div>
                        )}
                        
                        {/* Selected report triggers for visual feedback */}
                        {isAnalyzed && entry.analysis?.detectedTriggers && entry.analysis.detectedTriggers.length > 0 && (
                          <div className="flex flex-wrap gap-1 items-center">
                            <span className="text-[9px] font-bold text-neutral-400 mr-1">Triggers:</span>
                            {entry.analysis?.detectedTriggers.map((t, idx) => (
                              <span key={idx} className="text-[10px] bg-red-50 text-red-600 px-2 py-0.5 rounded-md font-medium border border-red-100">
                                {t}
                              </span>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}
            </div>
          )}
        </div>
      </div>

      {/* Column B: Analysis Report of Selected Entry (5/12) */}
      <div className="lg:col-span-12 xl:col-span-5 space-y-6 lg:order-last">
        {/* Detail view of active analysis */}
        <div className="bg-white rounded-xl border border-neutral-200 p-5 shadow-sm sticky top-6">
          <div className="flex items-center justify-between mb-4 border-b border-neutral-100 pb-3">
            <div className="flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-indigo-500 fill-indigo-100 animate-spin-slow" />
              <h2 className="text-base font-bold text-neutral-800">Psychological Wellness Report</h2>
            </div>
            
            <span className="text-[9px] px-2 py-0.5 bg-neutral-100 font-mono text-neutral-500 uppercase rounded font-bold">
              Real-time Analysis
            </span>
          </div>

          {entries.length === 0 ? (
            <div className="py-24 text-center text-xs text-neutral-400">
              No journal submitted yet. Fill out the daily emotional log to see the report format.
            </div>
          ) : (
            (() => {
              const activeEntry = entries[entries.length - 1]; // Focus on the most recent entries
              
              if (activeEntry.status === "pending") {
                return (
                  <div className="py-24 text-center space-y-3">
                    <Loader2 className="w-10 h-10 animate-spin text-indigo-600 mx-auto" />
                    <p className="text-xs text-neutral-500 font-mono">
                      Querying local Gemini model parameters and applying AES CBC encryption block...
                    </p>
                  </div>
                );
              }

              if (activeEntry.status === "error" || !activeEntry.analysis) {
                return (
                  <div className="py-24 text-center text-xs text-red-500">
                    Failed to finalize analysis on this entry. Please verify details and try again.
                  </div>
                );
              }

              const { analysis } = activeEntry;

              // Compose descriptive voice read payload
              const textToSpeak = `${analysis.personalizedNudge}. Here are your suggested coping exercises: ${analysis.copingStrategies.map(s => s.title).join(" and ")}. Please try following these steps.`;

              return (
                <div className="space-y-5 leading-normal">
                  
                  {/* Empathetic motivational encouragement section with Speech Playback */}
                  <div className="p-4 bg-indigo-50/50 rounded-xl border border-indigo-100 space-y-3 relative group">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-indigo-700 uppercase flex items-center gap-1 tracking-wider">
                        👑 Dynamic Wellness Assistant
                      </span>
                      
                      <div className="flex items-center gap-1.5">
                        {speakingId === activeEntry.id ? (
                          <button
                            onClick={stopSpeaking}
                            className="p-1 px-2.5 rounded bg-rose-100 hover:bg-rose-200 text-rose-700 text-[10px] font-mono flex items-center gap-1 transition-all cursor-pointer font-bold"
                          >
                            <Square className="w-3 h-3 text-rose-600" /> Stop Speech
                          </button>
                        ) : (
                          <button
                            onClick={() => speakText(textToSpeak, activeEntry.id)}
                            className="p-1 px-2.5 rounded bg-indigo-100 hover:bg-indigo-200 text-indigo-700 text-[10px] font-mono flex items-center gap-1 transition-all cursor-pointer font-bold"
                          >
                            <Volume2 className="w-3 h-3 text-indigo-600" /> Read Out Loud
                          </button>
                        )}
                      </div>
                    </div>

                    <p className="text-xs text-indigo-900 leading-relaxed italic pr-6 font-medium">
                      &quot;{analysis.personalizedNudge}&quot;
                    </p>

                    <div className="text-[10px] text-indigo-500 font-mono mt-2 pt-2 border-t border-indigo-100/40 flex items-center gap-1">
                      <Volume2 className="w-3 h-3" /> Click Reader icon to listen in English/Hindi dialect.
                    </div>
                  </div>

                  {/* Indicators Details */}
                  <div className="grid grid-cols-2 gap-3.5">
                    {/* Burnout Risk Indicator */}
                    <div className="p-4 bg-rose-50/50 rounded-xl border border-rose-100 flex flex-col justify-between">
                      <span className="text-[10px] font-bold text-rose-500 uppercase tracking-wider block">
                        Burnout Fatigue
                      </span>
                      <div className="flex items-baseline mt-2 gap-1">
                        <span className="text-3xl font-extrabold font-mono text-rose-600">
                          {analysis.burnoutRisk}%
                        </span>
                      </div>
                      <div className="w-full bg-rose-100/50 rounded-full h-1.5 mt-3.5 overflow-hidden">
                        <div
                          className="bg-rose-500 h-1.5 rounded-full"
                          style={{ width: `${analysis.burnoutRisk}%` }}
                        ></div>
                      </div>
                    </div>

                    {/* Dominant emotional markers */}
                    <div className="p-4 bg-amber-50/40 rounded-xl border border-amber-100 flex flex-col justify-between">
                      <span className="text-[10px] font-bold text-amber-700 uppercase tracking-wider block">
                        Dominant Emotions
                      </span>
                      <div className="flex flex-wrap gap-1 mt-2 mb-1">
                        {analysis.dominantEmotions?.map((e, idx) => (
                          <span
                            key={idx}
                            className="px-2 py-0.5 rounded-md text-[10.5px] bg-amber-500/15 text-amber-800 font-bold capitalize"
                          >
                            {e}
                          </span>
                        ))}
                      </div>
                      <p className="text-[9px] text-amber-600 font-mono font-medium leading-tight">
                        Mapped from raw journaling nuances.
                      </p>
                    </div>
                  </div>

                  {/* Cognitive Distortions panel */}
                  {analysis.cognitiveDistortions && analysis.cognitiveDistortions.length > 0 && (
                    <div className="p-4 bg-neutral-50 rounded-xl border border-neutral-200">
                      <span className="text-[10px] font-extrabold text-neutral-500 uppercase tracking-wider flex items-center gap-1 pb-2 border-b border-neutral-200 mb-2.5">
                        <Info className="w-3.5 h-3.5" /> Found Cognitive Distortions
                      </span>
                      <div className="space-y-2">
                        {analysis.cognitiveDistortions.map((d, index) => (
                          <div key={index} className="flex gap-2 items-start text-xs">
                            <span className="text-red-500 text-xs mt-0.5">⚡</span>
                            <div>
                              <strong className="text-neutral-700 font-semibold">{d}</strong>
                              <p className="text-[10.5px] text-neutral-500 leading-normal mt-0.5">
                                Cognitive biases that increase exam anxiety. Challenge this thought during mock reviews.
                              </p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Tailored Adaptive Coping Exercises */}
                  {analysis.copingStrategies && analysis.copingStrategies.length > 0 && (
                    <div className="space-y-3">
                      <span className="text-[10px] font-extrabold text-neutral-500 uppercase tracking-wider block">
                        Tailored Coping Exercises ({analysis.copingStrategies.length})
                      </span>

                      <div className="space-y-3">
                        {analysis.copingStrategies.map((s, index) => (
                          <div
                            key={index}
                            className="p-4 bg-white hover:bg-neutral-50/50 rounded-xl border border-neutral-200 space-y-2.5 transition-all shadow-sm"
                          >
                            <div className="flex justify-between items-start gap-2">
                              <h4 className="text-xs font-bold text-neutral-800">{s.title}</h4>
                              <div className="flex gap-1 shrink-0">
                                <span className={`text-[9px] font-mono uppercase font-bold px-1.5 py-0.5 rounded border ${
                                  s.difficulty === "Easy"
                                    ? "bg-emerald-50 text-emerald-700 border-emerald-200"
                                    : s.difficulty === "Medium"
                                    ? "bg-amber-50 text-amber-700 border-amber-200"
                                    : "bg-red-50 text-red-700 border-red-200"
                                }`}>
                                  {s.difficulty}
                                </span>
                                <span className="text-[9px] font-semibold bg-neutral-100 text-neutral-600 px-1.5 py-0.5 rounded font-mono">
                                  {s.durationMinutes}m
                                </span>
                              </div>
                            </div>

                            <p className="text-[10.5px] font-mono text-indigo-600 font-semibold uppercase tracking-wider">
                              ↳ Technique Type: {s.type}
                            </p>

                            <ol className="space-y-1.5 pl-1.5">
                              {s.steps?.map((step, idx) => (
                                <li key={idx} className="text-xs text-neutral-600 flex items-start gap-1.5 leading-relaxed">
                                  <span className="text-[10px] font-bold font-mono text-indigo-500 mt-0.5 shrink-0">
                                    {idx + 1}.
                                  </span>
                                  <span>{step}</span>
                                </li>
                              ))}
                            </ol>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Pattern interpretation */}
                  {analysis.emotionalPatterns && (
                    <div className="text-[11px] text-neutral-500 bg-neutral-50 p-3 rounded-lg border border-neutral-100">
                      <strong className="text-neutral-700 font-bold block mb-1">🔍 Academic Core Pattern:</strong>
                      <p className="leading-relaxed leading-normal">{analysis.emotionalPatterns}</p>
                    </div>
                  )}

                </div>
              );
            })()
          )}
        </div>
      </div>

      {/* --- Two-Step Verification (2SV) Secure Modal Popup Overlay --- */}
      {show2SvPopup && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[100] flex items-center justify-center p-4 transition-all duration-300">
          <div className="bg-white w-full max-w-md rounded-3xl border border-slate-200 p-6 shadow-2xl relative animate-in fade-in zoom-in-95 duration-200" id="secured-2sv-modal">
            
            {/* Header branding */}
            <div className="flex items-center gap-3 mb-5 border-b border-slate-100 pb-4">
              <div className="p-2.5 bg-indigo-50 rounded-2xl text-indigo-600">
                <KeyRound className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-base font-extrabold text-slate-900 tracking-tight">Sahaya Safe Recovery Vault</h3>
                <p className="text-[10px] text-slate-400 font-semibold uppercase tracking-wider flex items-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5 inline text-indigo-600" />
                  Two-Step Verification (2SV) Active
                </p>
              </div>
            </div>

            {twoSvError && (
              <div className="p-3 mb-4 bg-red-50 text-red-700 text-xs rounded-xl border border-red-100/30 font-semibold leading-relaxed">
                ⚠️ {twoSvError}
              </div>
            )}

            {twoSvSuccess && (
              <div className="p-3 mb-4 bg-indigo-50 text-indigo-800 text-xs rounded-xl border border-indigo-100/30 font-semibold leading-relaxed">
                💡 {twoSvSuccess}
              </div>
            )}

            {/* Step Content */}
            <div className="space-y-4">
              {twoSvStep === "register_pin" && (
                <div className="space-y-3">
                  <p className="text-xs text-slate-600 leading-normal">
                    To safeguard emotional logs, configure a personal <strong>6-digit Master PIN</strong> first. This acts as your secure password factor.
                  </p>
                  <div>
                    <label htmlFor="2sv-reg-pin" className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1.5 font-mono">
                      Choose Your Secure 6-Digit PIN
                    </label>
                    <div className="relative">
                      <input
                        id="2sv-reg-pin"
                        type={showPin ? "text" : "password"}
                        maxLength={6}
                        pattern="\d*"
                        value={pinValue}
                        placeholder="Ex. 123456"
                        onChange={(e) => setPinValue(e.target.value.replace(/\D/g, ""))}
                        className="w-full text-center tracking-[0.5em] text-lg p-3 bg-slate-50 border border-slate-200 focus:border-indigo-500 focus:outline-none rounded-xl font-mono pr-12"
                      />
                      <button
                        type="button"
                        onClick={() => setShowPin(!showPin)}
                        className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-indigo-600 cursor-pointer"
                        aria-label={showPin ? "Hide PIN digits" : "Show PIN digits"}
                      >
                        {showPin ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>
                  
                  <button
                    onClick={handleRegisterPin}
                    disabled={is2SvLoading || pinValue.length !== 6}
                    className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white disabled:bg-slate-200 disabled:text-slate-400 font-bold text-xs rounded-xl transition-all cursor-pointer shadow-md shadow-indigo-100"
                  >
                    {is2SvLoading ? "Configuring Safety PIN..." : "Configure PIN & Continue to OTP Check"}
                  </button>
                </div>
              )}

              {twoSvStep === "enter_pin" && (
                <div className="space-y-3">
                  <p className="text-xs text-slate-600 leading-normal">
                    This account is secure. Please input your verified <strong>6-digit security PIN</strong> to request a temporary One-Time Passcode challenge.
                  </p>
                  <div>
                    <label htmlFor="2sv-verify-pin" className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1.5 font-mono">
                      Your 6-Digit Master PIN
                    </label>
                    <div className="relative">
                      <input
                        id="2sv-verify-pin"
                        type={showPin ? "text" : "password"}
                        maxLength={6}
                        pattern="\d*"
                        value={pinValue}
                        placeholder="••••••"
                        onChange={(e) => setPinValue(e.target.value.replace(/\D/g, ""))}
                        className="w-full text-center tracking-[0.5em] text-lg p-3 bg-slate-50 border border-slate-200 focus:border-indigo-500 focus:outline-none rounded-xl font-mono pr-12"
                      />
                      <button
                        type="button"
                        onClick={() => setShowPin(!showPin)}
                        className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-indigo-600 cursor-pointer"
                        aria-label={showPin ? "Hide PIN digits" : "Show PIN digits"}
                      >
                        {showPin ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>
                  
                  <button
                    onClick={handleVerifyPinOnly}
                    disabled={is2SvLoading || pinValue.length !== 6}
                    className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white disabled:bg-slate-200 disabled:text-slate-400 font-bold text-xs rounded-xl transition-all cursor-pointer shadow-md shadow-indigo-100"
                  >
                    {is2SvLoading ? "Verifying PIN..." : "Verify PIN & Request Secure OTP"}
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setPinValue("");
                      setOtpValue("");
                      setTwoSvError("");
                      setTwoSvStep("register_pin");
                    }}
                    className="w-full text-[10.5px] font-semibold text-slate-550 hover:text-indigo-600 text-center transition-colors block border-t border-slate-150 pt-2.5 mt-2 cursor-pointer font-mono"
                  >
                    🔐 {logT.forgotPinLink}
                  </button>
                </div>
              )}

              {twoSvStep === "enter_otp" && (
                <div className="space-y-3 animate-in fade-in slide-in-from-bottom-2 duration-150">
                  <p className="text-xs text-slate-600 leading-normal">
                    We sent a temporary verification passcode to: <strong className="text-slate-800">{otpInfo?.maskedEmail || "ajay***@gmail.com"}</strong>. Input it below along with your PIN.
                  </p>

                  {/* HIGH VALUE: Elegant Preview Sandbox Code Indicator */}
                  {otpInfo?.debugOtp && (
                    <div className="p-3 bg-amber-50/70 border border-amber-200 rounded-2xl">
                      <div className="flex items-start gap-2">
                        <span className="text-amber-500 text-sm">🛡️</span>
                        <div>
                          <strong className="text-[11px] text-amber-800 font-bold block font-mono">Sandbox Authenticator Emulator</strong>
                          <p className="text-[10.5px] text-amber-900 leading-normal mt-0.5 font-mono">
                            OTP dispatched to Ajay's inbox: <span className="bg-amber-200/50 px-1.5 py-0.5 rounded text-amber-900 font-extrabold">{otpInfo.debugOtp}</span>
                          </p>
                        </div>
                      </div>
                    </div>
                  )}

                  <div className="grid grid-cols-2 gap-3 pt-1">
                    <div>
                      <label htmlFor="2sv-final-pin" className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1.5 font-mono">
                        Pin (Factor 1)
                      </label>
                      <div className="relative">
                        <input
                          id="2sv-final-pin"
                          type={showPin ? "text" : "password"}
                          maxLength={6}
                          pattern="\d*"
                          value={pinValue}
                          placeholder="••••••"
                          onChange={(e) => setPinValue(e.target.value.replace(/\D/g, ""))}
                          className="w-full text-center tracking-[0.25em] text-sm p-3 bg-slate-50 border border-slate-200 focus:border-indigo-500 focus:outline-none rounded-xl font-mono pr-10"
                        />
                        <button
                          type="button"
                          onClick={() => setShowPin(!showPin)}
                          className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-indigo-600 cursor-pointer"
                          aria-label={showPin ? "Hide PIN digits" : "Show PIN digits"}
                        >
                          {showPin ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                        </button>
                      </div>
                    </div>
                    <div>
                      <label htmlFor="2sv-final-otp" className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1.5 font-mono">
                        Otp (Factor 2)
                      </label>
                      <input
                        id="2sv-final-otp"
                        type="text"
                        maxLength={6}
                        pattern="\d*"
                        value={otpValue}
                        placeholder="Ex. 123456"
                        onChange={(e) => setOtpValue(e.target.value.replace(/\D/g, ""))}
                        className="w-full text-center tracking-[0.25em] text-sm p-3 bg-slate-50 border border-slate-200 focus:border-indigo-500 focus:outline-none rounded-xl font-mono text-indigo-600 font-bold"
                      />
                    </div>
                  </div>
                  
                  <button
                    onClick={handleVerify2SvComplete}
                    disabled={is2SvLoading || pinValue.length !== 6 || otpValue.length !== 6}
                    className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white disabled:bg-slate-200 disabled:text-slate-400 font-extrabold text-xs rounded-xl transition-all cursor-pointer shadow-md shadow-indigo-100/50 mt-1"
                  >
                    {is2SvLoading ? "Decrypting secure session..." : "Verify Factors & Grant Decryption Auth"}
                  </button>

                  <button
                    onClick={dispatchOtpChallenge}
                    disabled={is2SvLoading}
                    className="w-full text-[10px] font-mono font-bold text-indigo-600 hover:text-indigo-800 text-center uppercase block mt-1 transition-colors cursor-pointer"
                  >
                    Resend OTP Code
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setPinValue("");
                      setOtpValue("");
                      setTwoSvError("");
                      setTwoSvStep("register_pin");
                    }}
                    className="w-full text-[10.5px] font-semibold text-slate-550 hover:text-indigo-600 text-center transition-colors block border-t border-slate-150 pt-2.5 mt-2 cursor-pointer font-mono"
                  >
                    🔐 {logT.forgotPinLink}
                  </button>
                </div>
              )}
            </div>

            {/* Dialog Footer Actions */}
            <div className="mt-5 pt-3.5 border-t border-slate-50 flex justify-end gap-2">
              <button
                onClick={() => {
                  setShow2SvPopup(false);
                  setActiveDecTask(null);
                }}
                className="px-4 py-2 border border-slate-200 hover:bg-slate-50 text-slate-500 font-bold text-xs rounded-xl transition-all cursor-pointer"
              >
                Cancel/Close
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
}
